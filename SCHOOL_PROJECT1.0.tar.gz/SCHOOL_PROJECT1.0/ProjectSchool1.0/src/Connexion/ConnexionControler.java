package Connexion;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

import GestionAdmin.TestAdmin;
import coucheControler.DataBaseConnection;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
 


public class ConnexionControler {
 
	public static String ADMIN ;
	public static StringProperty SECRETAIRE ;
	public static StringProperty ETUDIANT ;
	public static StringProperty ENSEIGNANT ;
	public static StringProperty DIRECTEUR ;
	
    @FXML
    private AnchorPane pan1;

    @FXML
    private AnchorPane pane2;

    @FXML
    private TextField username;

    @FXML
    private Button bttonOk;

    @FXML
    private Button bttonAnnuler;

    @FXML
    private PasswordField pwd;

    @FXML
    private AnchorPane pan3;

    @FXML
    private Button fermer;
    
    
    @FXML
    private ComboBox<String> comboBox;
    
    @FXML public void initialize() { 
    	 
    	comboBox.getItems().addAll("ADMIN", "SECRETAIRE", "ENSEIGNANT", "ETUDIANT", "DIRECTEUR"); 
    	
    }

    @FXML
    void FermerApplication(ActionEvent event) {
    	System.exit(0);

    }

    @FXML
    void Renitialiser(ActionEvent event) {
    	username.setText(null);
    	pwd.setText(null);
    }

    @FXML
    void seConnecter(ActionEvent event)throws IOException {
 
        	Parent home = FXMLLoader.load(getClass().getResource("/Menu_School_Admin/ViewAdmin.fxml"));
        	Scene home_scene = new Scene (home);
        	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();

         	if(verificationUsers() && comboBox.getValue().equals("ADMIN") ) {
        		app.hide();
        		app.setScene(home_scene);
        		app.show();  
        		
         }
         	
         	
        	else {
    	          //System.out.println("Error!!!");

            	Parent homeSecretaire = FXMLLoader.load(getClass().getResource("/MenuSecretaire/MenuSecretaire.fxml"));
            	Scene home_sceneSecretaire = new Scene (homeSecretaire);
            	Stage appSecretaire = (Stage)((Node) event.getSource()).getScene().getWindow();	
     
              if(verificationUsers() && comboBox.getValue().equals("SECRETAIRE")) {
            		app.hide();
            		app.setScene(home_sceneSecretaire);
            		appSecretaire.show();
             
              }else {
          	         // System.out.println("Error!!!");
                Parent homeEtudiant = FXMLLoader.load(getClass().getResource("/MenuEtudiant/FXMLNotes.fxml"));
              	Scene home_sceneEtudiant = new Scene (homeEtudiant);
              	Stage appEtudiant = (Stage)((Node) event.getSource()).getScene().getWindow();
              	
                if(verificationUsers() && comboBox.getValue().equals("ETUDIANT")) {
              		app.hide();
              		app.setScene(home_sceneEtudiant);
              		appEtudiant.show();              	
            } else {
                // System.out.println("Error!!!");
                Parent homeEnseignant = FXMLLoader.load(getClass().getResource("/MenuEtudiant/FXMLNotes.fxml"));
              	Scene home_sceneEnseignant = new Scene (homeEnseignant);
              	Stage appEnseignant = (Stage)((Node) event.getSource()).getScene().getWindow();
              	
                if(verificationUsers() && comboBox.getValue().equals("ENSEIGNANT")) {
              		app.hide();
              		app.setScene(home_sceneEnseignant);
              		appEnseignant.show(); 
                
                } else {
                Parent homeComptable = FXMLLoader.load(getClass().getResource("/MenuDirecteur/ViewDirecteur.fxml"));
             	Scene home_sceneComptable = new Scene (homeComptable);
               	Stage appComptable = (Stage)((Node) event.getSource()).getScene().getWindow();
                  	
                    if(verificationUsers() && comboBox.getValue().equals("DIRECTEUR")) {
                  		app.hide();
                  		app.setScene(home_sceneComptable);
                  		appComptable.show(); 
                    
                    } else {
                    	System.out.println("Error!!!");
                    }
                }
            }
          }
       	}
      }
         	 
    public boolean verificationUsers() {
    	boolean estValide = false ;
    	String  usernames = null, password = null;
    	 System.out.println( "SELECT * FROM  Authentification WHERE Users= " + "'" + username.getText() + "'" 
    	       + " AND Passwords= " + "'" + pwd.getText() + "'" );
    	 Connection conn = (Connection) DataBaseConnection.getConnection() ;
    	 java.sql.Statement ps;
		try {
			ps = conn.createStatement();
		     
             ResultSet res = ps.executeQuery( "SELECT * FROM Authentification WHERE Users= " + "'" + username.getText() + "'" 
             + " AND Passwords= " + "'" + pwd.getText() + "'");
	 
			while(res.next()) {
				if ((res.getString("Users") != null) && (res.getString("Passwords") != null)) {
					
                      usernames = res.getString("Users");
                    System.out.println( "USERNAME = " + usernames );     
                     password = res.getString("Passwords");
                    System.out.println("PASSWORD = " + password);
                    estValide = true;
			   }
        
			}
			res.close();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
	        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);
			//e.printStackTrace();
		}	
    	
    	return estValide ;
    }
   }
	

