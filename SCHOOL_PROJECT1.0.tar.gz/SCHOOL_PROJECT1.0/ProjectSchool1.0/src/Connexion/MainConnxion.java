package Connexion;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
 
import javafx.stage.Stage;

public class MainConnxion extends Application {


	@Override
	public void start(Stage stage)throws Exception {
		
		
			Parent root = FXMLLoader.load(getClass().getResource("FXMLConnexion.fxml"));
		stage.setTitle("Projet Gestion School1.0");
		Scene scene = new Scene(root) ;  
		stage.setScene(scene);
 
		 
		/*}catch (Exception e) {
			// TODO: handle exception
		}*/
		stage.show();

	}
	
	
	public static void main(String[] args) {
         launch(args);

	}


}
