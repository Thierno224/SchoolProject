package GestionEtudiant;


import java.util.Date;
import java.util.List;

import coucheControler.Metier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
 
import partieConsole.Etudiant;

public class EtudiantController {
	

    @FXML
    private AnchorPane pan1;

    @FXML
    private TextField text4;

    @FXML
    private TextField text5;

    @FXML
    private TextField text6;

    @FXML
    private TextField text7;

    @FXML
    private TextField text8;

    @FXML
    private TextField text14;

    @FXML
    private TextField text13;

    @FXML
    private TextField text10;

    @FXML
    private TextField text9;

    @FXML
    private TextField text15;

    @FXML
    private TextField text16;

    @FXML
    private TextField text17;

    @FXML
    private TextField text18;

    @FXML
    private TextField text19;

    @FXML
    private AnchorPane pan4;

    @FXML
    private Label lab21;

    @FXML
    private TextField text3;

    @FXML
    private Button suppEns;

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private Button bttajouter;

    @FXML
    private AnchorPane pan3;

    @FXML
    private Label lab1;

    @FXML
    private TextField text1;

    @FXML
    private Button affiche1;

    @FXML
    private Label lab2;

    @FXML
    private TextField text2;

    @FXML
    private TableView<Etudiant> Table;

    @FXML
    private TableColumn<Etudiant, Integer> matricule;

    @FXML
    private TableColumn<Etudiant, String> nom;

    @FXML
    private TableColumn<Etudiant, String> prenom;

    @FXML
    private TableColumn<Etudiant, String> genre;

    @FXML
    private TableColumn<Etudiant, Date> naissance;

    @FXML
    private TableColumn<Etudiant, String> lieuNaiss;

    @FXML
    private TableColumn<Etudiant, String> niveau;

    @FXML
    private TableColumn<Etudiant, String> domaine;

    @FXML
    private TableColumn<Etudiant, String> profil;

    @FXML
    private TableColumn<Etudiant, String> competence;

    @FXML
    private TableColumn<Etudiant, String> langMat;

    @FXML
    private TableColumn<Etudiant, String> langParle;

    @FXML
    private TableColumn<Etudiant, String> phone;

    @FXML
    private TableColumn<Etudiant, String> mail;

    @FXML
    private TableColumn<Etudiant, String> adresse;

    @FXML
    private Button motCleOK;

    @FXML
    private Button boutton;
 
    
    @FXML public void initialize() { 

    	comboBox.getItems().addAll("H", "F"); 
    	
    }
    
    
    Metier m =new Metier () ;
 
   private ObservableList<Etudiant> observableArrayList = FXCollections.observableArrayList(); 
 
   
   
   private List<Etudiant> observableArrayList2 = FXCollections.observableArrayList();
   private ObservableList<Etudiant> observableArrayList3 = FXCollections.observableArrayList();
   private ObservableList<Etudiant> observableArrayList1 = FXCollections.observableArrayList();
   Etudiant observableArrayList5 ;
   

    @FXML
    void Validation(ActionEvent event) {
   	 
        Etudiant e = null;
    	int num = Integer.parseInt(text2.getText());
    	e = m.RechercherEtudiantMatricule(num);
    	observableArrayList1.add(e);

    	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
    	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
    	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
    	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
    	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
    	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
    	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
    	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
    	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
    	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
    	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
    	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
    	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
    	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
    	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
    	//observableArrayList3.addAll(observableArrayList5);

    	Table.setItems(observableArrayList1);
    }

    @FXML
    void AfficherAll(ActionEvent event) {
    	observableArrayList.addAll(m.AfficherAllEtudiant());
    	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
    	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
    	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
    	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
    	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
    	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
    	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
    	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
    	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
    	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
    	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
    	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
    	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
    	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
    	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
 
    	Table.setItems(observableArrayList);

    }

    @FXML
    void ChercheMC(ActionEvent event) {

   	 String mc = text1.getText();
   	 Table.refresh(); 
   	 observableArrayList2 =  m.RechercherEtudiantMC(mc);

   	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
   	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
   	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
   	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
   	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
   	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
   	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
   	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
   	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
   	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
   	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
   	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
   	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
   	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
   	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
   	observableArrayList3.addAll(observableArrayList2);
   	Table.setItems(observableArrayList3);

    }
  

     @FXML
     void SupprimerEtudiant(ActionEvent event) {
    	System.out.println("Hello world !!! ");
    	 int id = Integer.parseInt(text3.getText());
    	    m.SupprimerEtudiant(id); 


     }
     
     @FXML
     void AddEtudiant(ActionEvent event) {
     	int id = Integer.parseInt(text4.getText());
     //	SingleSelectionModel<String> var = comboBox.getSelectionModel();
  	    Etudiant e = new Etudiant(id, text5.getText(), text6.getText(),comboBox.getValue(), null, text8.getText(), text9.getText(),text10.getText()
  	    		                     ,text13.getText(), text14.getText(),text15.getText(), text16.getText(), text17.getText(), text18.getText(),text19.getText()) ;
            System.out.println("Hello");
            
  	    	   m.AjouterEtudiant(e);

     }




}
