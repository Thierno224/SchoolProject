package Connection.utilisateurs;

import java.sql.Connection;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
 
public class ConnexionUser {
	private static String user1 = "Administrateur" ;
	private static String user2 = "Etudiant" ;
	private static String user3 = "Enseignant" ;
	private static String user4 = "Secretaire" ;
	private static String user5 = "Comptable" ;
	

	private final SimpleIntegerProperty identifiant;
	private final StringProperty name ;
	private final StringProperty password ;
	private final SimpleIntegerProperty level;
	
	public ConnexionUser(int identifiant, String name, String password, int level) {
		this.identifiant = new SimpleIntegerProperty(identifiant);
		this.name = new SimpleStringProperty(name);
		this.password = new SimpleStringProperty(password) ;
		this.level = new SimpleIntegerProperty(level);
 
	}

   public Integer getIdentifiant () {   return identifiant.get() ; }
   
   public String getName () { return name.get() ; }
   
   public String getPassword () { return password.get() ; }
   
   public Integer getLevel () {   return level.get() ; }
   
   //------------------- 	LES SETTERS	---------------------------
   
   public void setIdentifiant (int value) { identifiant.set(value); } 
   
   public void setName (String value) { name.set(value); }
   
   public void setPassword (String value) { password.set(value); } 
   
   public void setLevel (int value) { level.set(value); } 
   
   // Property value 
   
   public IntegerProperty identifiantProperty() {
	   return identifiant ;
   }
   
   public StringProperty nameProperty() {
	   return name ;
   }
   
   public StringProperty passwordProperty() {
	   return password ;
   }
   
   
   public IntegerProperty levelProperty() {
	   return level ;
   }
   
   
}
