package Connection.utilisateurs;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;
	import com.jfoenix.controls.JFXComboBox;
	import com.jfoenix.controls.JFXTextField;

import coucheControler.EtudiantControler;
import javafx.fxml.FXML;
	import javafx.scene.control.Label;

	public class EudiantController implements Initializable {
		
		ObservableList<String> genreStatusList = FXCollections.observableArrayList("Homme", "Femme") ;

	    @FXML
	    private JFXButton buttonAjouter;

	    @FXML
	    private JFXButton buttonModifier;

	    @FXML
	    private Label identifiant;

	    @FXML
	    private Label nom;

	    @FXML
	    private Label prenom;

	    @FXML
	    private Label genre;

	    @FXML
	    private Label dateNaissance;

	    @FXML
	    private Label lieuNaissance;

	    @FXML
	    private Label niveau;

	    @FXML
	    private Label domaine;

	    @FXML
	    private Label profilTextField;

	    @FXML
	    private Label competenceTextField;

	    @FXML
	    private Label langMaternelle;

	    @FXML
	    private Label langParlee;

	    @FXML
	    private Label telephone;

	    @FXML
	    private Label mail;

	    @FXML
	    private Label adresse;

	    @FXML
	    private JFXTextField identfText;

	    @FXML
	    private JFXTextField nomTextField;

		@FXML
	    private JFXTextField prenomTextField;

	    @FXML
	    private JFXTextField naissanceTextField;

	    @FXML
	    private JFXTextField lieuNaissTextField;

	    @FXML
	    private JFXTextField niveauTextField;

	    @FXML
	    private JFXTextField domaineTextField;

	    @FXML
	    private JFXTextField maternelleTextField;

	    @FXML
	    private JFXTextField langTextField;

	    @FXML
	    private JFXTextField telephoneTextField;

	    @FXML
	    private JFXTextField mailTextField;

	    @FXML
	    private JFXTextField numRue;

	    @FXML
	    private JFXComboBox<String> genreTextField;

	    @FXML
	    private Label idRue;

	    @FXML
	    private Label voie;

	    @FXML
	    private JFXTextField nomRue;

	    @FXML
	    private Label nomVille;

	    @FXML
	    private Label codePostal;

	    @FXML
	    private JFXTextField postal;

	    @FXML
	    private JFXTextField ville;

	    @FXML
	    private JFXButton buttonValider;

	    @FXML
	    private JFXButton buttonAnnuler;

	    @FXML
	    void Ajouter(ActionEvent event) {

	    }
	    
	    @FXML
	    void AnnulerAjout(ActionEvent event) {

	    }

	    @FXML
	    void ValiderAjout(ActionEvent event) {

	    }

	    @FXML
	    void valider(ActionEvent event) {

	    }

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			genreTextField.setValue("Homme");
			genreTextField.setItems(genreStatusList);
		}

	}

