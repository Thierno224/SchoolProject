package MenuDirecteur;
import java.io.IOException;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MenuDirecteurController {

    @FXML
    private JFXButton bMenuEtudiant;

    @FXML
    private JFXButton bMenuEnseignant;

    @FXML
    private JFXButton bMenuSEcretaire;

    @FXML
    private JFXButton bMenuDirecteur;

    @FXML
    private JFXButton bMenuMat;

    @FXML
    private JFXButton bMenuSession;

    @FXML
    private JFXButton bMenuEta;
 


    @FXML
    void MenuSalle(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/MatiereSession/Page_Matiere_Module.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();
    }

    @FXML
    void MenuEnseignant(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/GestionEnseignant/FXMLEnseignant.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();
 
    }

    @FXML
    void MenuEta(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/SeesionGroupe/PageSessionGroupe.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();

    }

    @FXML
    void MenuEtudiant(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/GestionEtudiant/FXMLEnseignant.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();

    }

    @FXML
    void MenuMat(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/MatiereSession/Page_Matiere_Module.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();
    }

    @FXML
    void MenuSecretaire(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/GestionSecretaire/FXMLEnseignant.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();
    }

    @FXML
    void MenuSession(ActionEvent event) throws IOException {
     	Parent home = FXMLLoader.load(getClass().getResource("/SeesionGroupe/PageSessionGroupe.fxml"));
    	Scene home_scene = new Scene (home);
    	Stage app = (Stage)((Node) event.getSource()).getScene().getWindow();
    	app.hide();
		app.setScene(home_scene);
		app.show();

    }

}
