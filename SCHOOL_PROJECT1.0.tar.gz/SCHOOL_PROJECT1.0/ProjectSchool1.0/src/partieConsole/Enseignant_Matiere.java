package partieConsole;

import java.sql.Date;
import java.time.LocalDate;

public class Enseignant_Matiere {
	
	protected Enseignant ens;
	protected Matiere mat;
	String nbHeure ;
    
	public Enseignant_Matiere(Enseignant ens, Matiere mat, String nbHeure) {
		super();
		this.ens = ens;
		this.mat = mat;
		this.nbHeure = nbHeure;
	}
    
	public Enseignant_Matiere() {
      super() ;
	}
	public Enseignant getEns() {
		return ens;
	}
	public void setEns(Enseignant ens) {
		this.ens = ens;
	}
	public Matiere getMat() {
		return mat;
	}
	public void setMat(Matiere mat) {
		this.mat = mat;
	}
	public String getNbHeure() {
		return nbHeure;
	}
	public void setNbHeure(String nbHeure) {
		this.nbHeure = nbHeure;
	}
	public void setMatiere(Matiere m) {
		 mat = m ;	
	}
	public void setEnseignant(Enseignant en) {
		 ens = en ;
		
	}
	

}
