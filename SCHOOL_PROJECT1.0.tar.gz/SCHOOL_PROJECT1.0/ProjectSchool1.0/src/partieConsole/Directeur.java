package partieConsole;

import java.sql.Date;

public class Directeur extends Individu {

	public Directeur() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Directeur(int idIndividu, String nomIndividu, String prenomIndividu, String genreIndividu,
			Date dateNaissIndividu, String lieuNaissIndividu, String niveauIndividu, String domEtudeIndividu,
			String profilIndividu, String domCompetenceIndividu, String langMaternelleIndividu,
			String langParleIndividu, String numTel, String mail, String adresseIndividu) {
		super(idIndividu, nomIndividu, prenomIndividu, genreIndividu, dateNaissIndividu, lieuNaissIndividu, niveauIndividu,
				domEtudeIndividu, profilIndividu, domCompetenceIndividu, langMaternelleIndividu, langParleIndividu, numTel,
				mail, adresseIndividu);
		// TODO Auto-generated constructor stub
	}

	

	
}
