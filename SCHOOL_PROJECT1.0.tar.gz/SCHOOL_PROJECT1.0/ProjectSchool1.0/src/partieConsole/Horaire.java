/**
 * 
 */
package partieConsole;

/**
 * @author Mamadou bobo
 *
 */
public class Horaire {
	private int idHoraire;
	private Session session;
	public Horaire(int idHoraire, Session session) {
		super();
		this.idHoraire = idHoraire;
		this.session = session;
	}
	public Horaire() {
		// TODO Auto-generated constructor stub
	}
	public int getIdHoraire() {
		return idHoraire;
	}
	public void setIdHoraire(int idHoraire) {
		this.idHoraire = idHoraire;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	
	

}
