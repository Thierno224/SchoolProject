/**
 * 
 */
package partieConsole;

import java.sql.Date;

/**
 * @author Mamadou bobo
 *
 */
public class Etudiant extends Individu {

	@Override
	public String toString() {
		return "" + getIdIndividu();
	}

	public Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Etudiant(int idIndividu) {
		super(idIndividu);
		// TODO Auto-generated constructor stub
	}


	public Etudiant(int idIndividu, String nomIndividu, String prenomIndividu, String genreIndividu,
			Date dateNaissIndividu, String lieuNaissIndividu, String niveauIndividu, String domEtudeIndividu,
			String profilIndividu, String domCompetenceIndividu, String langMaternelleIndividu,
			String langParleIndividu, String numTel, String mail, String adresseIndividu) {
		super(idIndividu, nomIndividu, prenomIndividu, genreIndividu, dateNaissIndividu, lieuNaissIndividu, niveauIndividu,
				domEtudeIndividu, profilIndividu, domCompetenceIndividu, langMaternelleIndividu, langParleIndividu, numTel,
				mail, adresseIndividu);
		// TODO Auto-generated constructor stub
	}
	//private int idAffectation;//A voir after
	
	
	



	

}
