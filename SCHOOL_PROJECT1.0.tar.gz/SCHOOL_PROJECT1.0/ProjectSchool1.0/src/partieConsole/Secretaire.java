/**
 * 
 */
package partieConsole;

import java.util.Date;
 
public class Secretaire extends Individu {
	//private int idAffectation;//A voir 

	public Secretaire() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Secretaire(int idIndividu, String nomIndividu, String prenomIndividu, String genreIndividu,
			java.sql.Date dateNaissIndividu, String lieuNaissIndividu, String niveauIndividu, String domEtudeIndividu,
			String profilIndividu, String domCompetenceIndividu, String langMaternelleIndividu,
			String langParleIndividu, String numTel, String mail, String adresseIndividu) {
		super(idIndividu, nomIndividu, prenomIndividu, genreIndividu, dateNaissIndividu, lieuNaissIndividu, niveauIndividu,
				domEtudeIndividu, profilIndividu, domCompetenceIndividu, langMaternelleIndividu, langParleIndividu, numTel,
				mail, adresseIndividu);
		// TODO Auto-generated constructor stub
	}


	
	
	
	

}
