package GestionAdmin;

 
import java.util.Date;
 
import coucheControler.Metier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import partieConsole.Administrateur;
 

public class AdminController {
	

ObservableList<String> list = FXCollections.observableArrayList();

	
	   @FXML
	    private AnchorPane pan1;

	    @FXML
	    private AnchorPane pan2;

	    @FXML
	    private AnchorPane pan3;

	    @FXML
	    private AnchorPane pan4;
	    @FXML
	    private Label lab1;

	    @FXML
	    private TextField text1;

	    @FXML
	    private Button mcValider;
	    @FXML
	    private Button affiche;

	    @FXML
	    private Button motCleOK;

	    @FXML
	    private Label lab2;

	    @FXML
	    private TextField text2;

	    @FXML
	    private Button boutton;
	    @FXML
	    private TextField text3;

	    @FXML
	    private TextField text4;

	    @FXML
	    private TextField text5;

	    @FXML
	    private TextField text6;

	    @FXML
	    private TextField text7;

	    @FXML
	    private TextField text8;

	    @FXML
	    private TextField text14;

	    @FXML
	    private TextField text13;

	    @FXML
	    private TextField text10;

	    @FXML
	    private TextField text9;

	    @FXML
	    private TextField text15;

	    @FXML
	    private TextField text16;

	    @FXML
	    private TextField text17;

	    @FXML
	    private TextField text18;

	    @FXML
	    private TextField text19;
	    @FXML
	    private Button bttajouter;

	    @FXML
	    private Button suppEns;

	    @FXML
	    private Button ajoutEns;
	    
	    @FXML
	    private TableView<Administrateur> Table;

	    @FXML
	    private TableColumn<Administrateur, Integer> matricule;
	    @FXML
	    private TableColumn<Administrateur, String> nom;
	    @FXML
	    private TableColumn<Administrateur, String> prenom;
	    @FXML
	    private TableColumn<Administrateur, String> genre;
	    @FXML
	    private TableColumn<Administrateur, Date> naissance;
	    @FXML
	    private TableColumn<Administrateur, String> lieuNaiss;
	    @FXML
	    private TableColumn<Administrateur, String> niveau;
	    @FXML
	    private TableColumn<Administrateur, String> domaine;
	    @FXML
	    private TableColumn<Administrateur, String> profil;
	    @FXML
	    private TableColumn<Administrateur, String> competence;
	    @FXML
	    private TableColumn<Administrateur, String> langMat;
	    @FXML
	    private TableColumn<Administrateur, String> langParle;
	    @FXML
	    private TableColumn<Administrateur, Integer> phone;
	    @FXML
	    private TableColumn<Administrateur, String> mail;
	    @FXML
	    private TableColumn<Administrateur, String> adresse;
 

	    @FXML
	    private DatePicker datePicker;

	    @FXML
	    private ComboBox<String> comboBox;
	    
	    @FXML public void initialize() { 
 
	    	comboBox.getItems().addAll("H", "F"); 
	    	
	    }
 
	     Metier m =new Metier () ;
	     
	     
	    private ObservableList<Administrateur> observableArrayList = FXCollections.observableArrayList
	    		                        (m.AfficherAllAdmin());
	  
		    
 	    private ObservableList<Administrateur> observableArrayList3 = FXCollections.observableArrayList();
	    private ObservableList<Administrateur> observableArrayList1 = FXCollections.observableArrayList();
  
	    @FXML
	    void Validation(ActionEvent event) {
	    	 
	    	Administrateur e = null;
	    	int num = Integer.parseInt(text2.getText());
	    	e = m.RechercherAdministrateurMatricule(num);
	    	observableArrayList1.add(e);

	    	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
	    	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
	    	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
	    	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
	    	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
	    	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
	    	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
	    	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
	    	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
	    	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
	    	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
	    	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
	    	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
	    	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
	    	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
	    	//observableArrayList3.addAll(observableArrayList5);

	    	Table.setItems(observableArrayList1);

	    }

	    
	    
	    @FXML
	    void AfficherAll(ActionEvent event) {

	    	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
	    	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
	    	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
	    	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
	    	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
	    	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
	    	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
	    	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
	    	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
	    	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
	    	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
	    	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
	    	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
	    	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
	    	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
	    	
	    	Table.setItems(observableArrayList);

	    }
	    
	    @FXML
	    void ChercheMC(ActionEvent event) {
	    	 
	    	 String mc = text1.getText();
 
	     observableArrayList3 =  FXCollections.observableArrayList(m.RechercherAdministrateurMC(mc));

	    	matricule.setCellValueFactory(new PropertyValueFactory<>("idIndividu"));
	    	nom.setCellValueFactory(new PropertyValueFactory<>("nomIndividu"));
	    	prenom.setCellValueFactory(new PropertyValueFactory<>("prenomIndividu"));
	    	genre.setCellValueFactory(new PropertyValueFactory<>("genreIndividu"));
	    	naissance.setCellValueFactory(new PropertyValueFactory<>("dateNaissIndividu"));
	    	lieuNaiss.setCellValueFactory(new PropertyValueFactory<>("LieuNaissIndividu"));
	    	niveau.setCellValueFactory(new PropertyValueFactory<>("niveauIndividu"));
	    	domaine.setCellValueFactory(new PropertyValueFactory<>("domEtudeIndividu"));
	    	profil.setCellValueFactory(new PropertyValueFactory<>("profilIndividu"));
	    	competence.setCellValueFactory(new PropertyValueFactory<>("domCompetenceIndividu"));
	    	langMat.setCellValueFactory(new PropertyValueFactory<>("langMaternelleIndividu"));
	    	langParle.setCellValueFactory(new PropertyValueFactory<>("langParleIndividu"));
	    	phone.setCellValueFactory(new PropertyValueFactory<>("numTel"));
	    	mail.setCellValueFactory(new PropertyValueFactory<>("mail"));
	    	adresse.setCellValueFactory(new PropertyValueFactory<>("adresseIndividu"));
	    
	    	Table.setItems(observableArrayList3);
	    	
         
	    }

	    @FXML
	    void SupprimerAdmin(ActionEvent event) {
	    	 
	    	int id = Integer.parseInt(text3.getText());
	    	m.SupprimerSecretaire(id); 

	    }
	    
	    @FXML
	    void AddAdmin(ActionEvent event) {
	    	int id = Integer.parseInt(text4.getText());
           
	    	Administrateur a = new Administrateur(id, text5.getText(), text6.getText(),comboBox.getValue() , datePicker.getValue(), text8.getText(), text9.getText(),text10.getText()
		    		                     ,text13.getText(), text14.getText(),text15.getText(), text16.getText(), text17.getText(), text18.getText(),text19.getText()) ;
             System.out.println("Hello");
             
 	    	   m.AjouterAdministarteur(a);;
	    }
 
	    
}
