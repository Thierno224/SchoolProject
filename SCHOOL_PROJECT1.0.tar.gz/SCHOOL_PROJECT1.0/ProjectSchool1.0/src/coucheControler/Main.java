package coucheControler;

 
import java.text.ParseException;
 
import java.text.SimpleDateFormat;
import java.sql.Date;

import partieConsole.Enseignant;
import partieConsole.Etudiant;
import partieConsole.Session;

public class Main {

	public static void main(String[] args){
     
	// Connection conn = DataBaseConnection.getConnection() ;
	
	 Metier metier = new Metier() ;
 
	/* 
	 
	// metier.AjouterEnseignant(new Enseignant(4, "Barry", "Mamadou bobo", "H", null , "Coyah", "Licene3", "MIAGE", "GEEK", "Java", "THôma", "Fraçais",  "0785963512", "barry.mamad.com", "Evry Concouronne"));
	//  metier.AjouterSession(new Session(2, 2010, "session2", (java.sql.Date) cDate , null));
   *//*
	 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		String dateStr = "07-Nov-2013";

		Date date = dateFormat.parse(dateStr);
		System.out.println(date);
		System.out.println(dateFormat.format(date));
*/
    	SimpleDateFormat datSimple = new SimpleDateFormat("dd/mm/yyyy");
    	Date date1=null;
    	Date date2=null;
     
    	//   date1 = datSimple.parse("15/01/2018");
    	 // date2 =  datSimple.parse("19/02/2018");
    	 System.out.println(date1);
    	 System.out.println(date2);
    	//metier.AjouterSession(new Session(3, 2015, "session2", date1 , date2));

	
 
	}

}
