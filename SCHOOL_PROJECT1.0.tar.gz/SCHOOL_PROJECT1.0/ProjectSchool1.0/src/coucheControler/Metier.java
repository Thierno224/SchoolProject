package coucheControler;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.PartialResultException;

import partieConsole.Administrateur;
import partieConsole.Directeur;
import partieConsole.Enseignant;
import partieConsole.Enseignant_Matiere;
import partieConsole.Etudiant;
import partieConsole.Groupe;
import partieConsole.Horaire;
import partieConsole.Inscription;
import partieConsole.Matiere;
import partieConsole.Module;
import partieConsole.NotesEtudiant;
import partieConsole.Paiement;
import partieConsole.Salle;
import partieConsole.Secretaire;
import partieConsole.Session;

public class Metier implements IMetier {
	List <Etudiant> listEtudiant = new ArrayList<Etudiant>() ;
	List <Enseignant> listEnseignant = new ArrayList<Enseignant>() ;
	List <Directeur> listDirecteur = new ArrayList<Directeur>() ;
	List <Administrateur> listAdmin = new ArrayList<Administrateur>() ;
	List <Secretaire> listSecretaire = new ArrayList<Secretaire>() ;
	List <Salle> listSalle = new ArrayList<>();
	List <Session> listSession = new ArrayList<>();
	List <Inscription> listInscris = new ArrayList<>();
	List <Groupe> listGroupe = new ArrayList<>();
	List <Module> listModule = new ArrayList<>();
	List <Matiere> listMatiere = new ArrayList<>();	
	List <NotesEtudiant> listNotes = new ArrayList<>();
	List <Enseignant_Matiere> listEnsMat = new ArrayList<>();

    
	@Override
	public void AjouterEtudiant(Etudiant e) {
		 Connection conn = DataBaseConnection.getConnection() ;
	 try {
		PreparedStatement ps = conn.prepareStatement("INSERT INTO Etudiant VALUES (?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)");

		ps.setInt(1, e.getIdIndividu());
		ps.setString(2, e.getNomIndividu());
		ps.setString(3, e.getPrenomIndividu());
		ps.setString(4, e.getGenreIndividu());
		ps.setDate(5, e.getDateNaissIndividu());
		ps.setString(6, e.getLieuNaissIndividu());
		ps.setString(7, e.getNiveauIndividu());
		ps.setString(8, e.getDomEtudeIndividu());
		ps.setString(9, e.getProfilIndividu());
		ps.setString(10, e.getDomCompetenceIndividu());
		ps.setString(11, e.getLangMaternelleIndividu());
		ps.setString(12, e.getLangParleIndividu());
		ps.setString(13, e.getNumTel());
		ps.setString(14, e.getMail());
		ps.setString(15, e.getAdresseIndividu());
		ps.executeUpdate() ;
		listEtudiant.add(e);
		
		
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		
	}

	@Override
	public Etudiant ModifierEtudiant(Etudiant o) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
	("UPDATE Etudiant SET ID_Etudiant = ?, Nom_Etudiant = ?, Prenom_Etudiant = ?,"
	 + "Genre = ?, Date_Naissance = ?, Lieu_Naissance = ?, Niveau = ?, Domaine = ?,"
	 + "Profil = ?, Competence = ?, Lang_Maternelle = ?, Lang_Parlee = ?, "
	 + "Telephone = ?, Email = ?, Adresse_Etudiant = ?");
			for(Etudiant e : listEtudiant) {
				if(e.getIdIndividu() == o.getIdIndividu()) {
					e.setIdIndividu(o.getIdIndividu());
					e.setNomIndividu(o.getNomIndividu());
					e.setPrenomIndividu(o.getPrenomIndividu());
					e.setGenreIndividu(o.getGenreIndividu());
					e.setDateNaissIndividu(o.getDateNaissIndividu());
					e.setNiveauIndividu(o.getNiveauIndividu());
					e.setDomEtudeIndividu(o.getDomEtudeIndividu());
					e.setPrenomIndividu(o.getProfilIndividu());
					e.setDomCompetenceIndividu(o.getDomCompetenceIndividu());
					e.setLangMaternelleIndividu(o.getLangMaternelleIndividu());
					e.setNumTel(o.getNumTel());
					e.setMail(o.getMail());
					e.setAdresseIndividu(o.getAdresseIndividu());
				}
				return e ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null ;
		
	}

	@Override
	public void SupprimerEtudiant(int idEtudiant) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete from Etudiant where ID_Etudiant = ?");
			ps.setInt(1, idEtudiant);
			for(Etudiant e : listEtudiant) {
				if(e.getIdIndividu() == idEtudiant) {
					listEtudiant.remove(e) ;
					System.out.println("Etudiant supprimé avec succès");
				}else
					System.out.println("Sorry , id not exist !!!");
			}
			ps.executeUpdate() ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
	}

	@Override
	public List<Etudiant> AfficherAllEtudiant() {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("SELECT * FROM Etudiant") ;
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Etudiant e = new Etudiant() ;
				e.setIdIndividu(res.getInt("ID_Etudiant"));
				e.setNomIndividu(res.getString("Nom_Etudiant"));
				e.setPrenomIndividu(res.getString("Prenom_Etudiant"));
				e.setGenreIndividu(res.getString("Genre"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau"));
				e.setDomCompetenceIndividu(res.getString("Domaine"));
				e.setProfilIndividu(res.getString("Profil"));
				e.setDomCompetenceIndividu(res.getString("Competence"));
				e.setLangMaternelleIndividu(res.getString("Lang_Maternelle"));
				e.setLangParleIndividu(res.getString("Lang_Parlee"));
				e.setNumTel(res.getString("Telephone"));
				e.setMail(res.getString("Email"));;
				e.setAdresseIndividu(res.getString("Adresse_Etudiant"));
				listEtudiant.add(e) ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listEtudiant;
	}

	@Override
	public List<Etudiant> RechercherEtudiantMC(String word) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Etudiant where Nom_Etudiant like ?");
			ps.setString(1,"%"+word+"%");
			ResultSet res=ps.executeQuery(); 
			while(res.next()){
				Etudiant e = new Etudiant() ;
				e.setIdIndividu(res.getInt("ID_Etudiant"));
				e.setNomIndividu(res.getString("Nom_Etudiant"));
				e.setPrenomIndividu(res.getString("Prenom_Etudiant"));
				e.setGenreIndividu(res.getString("Genre"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau"));
				e.setDomCompetenceIndividu(res.getString("Domaine"));
				e.setProfilIndividu(res.getString("Profil"));
				e.setDomCompetenceIndividu(res.getString("Competence"));
				e.setLangMaternelleIndividu(res.getString("Lang_Maternelle"));
				e.setLangParleIndividu(res.getString("Lang_Parlee"));
				e.setNumTel(res.getString("Telephone"));
				e.setMail(res.getString("Email"));;
				e.setAdresseIndividu(res.getString("Adresse_Etudiant"));
				listEtudiant.add(e) ;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listEtudiant;
	}

	@Override
	public Etudiant RechercherEtudiantMatricule(int matricule) {
	   Connection conn = DataBaseConnection.getConnection() ;
	   try {
		PreparedStatement ps = conn.prepareStatement
				   ("Select * from Etudiant where ID_Etudiant = ? ");
		ps.setInt(1, matricule);
		ResultSet res=ps.executeQuery(); 
		if(res.next()){
			Etudiant e = new Etudiant() ;
			e.setIdIndividu(res.getInt("ID_Etudiant"));
			e.setNomIndividu(res.getString("Nom_Etudiant"));
			e.setPrenomIndividu(res.getString("Prenom_Etudiant"));
			e.setGenreIndividu(res.getString("Genre"));
			e.setDateNaissIndividu(res.getDate("Date_Naissance"));
			e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
			e.setNiveauIndividu(res.getString("Niveau"));
			e.setDomCompetenceIndividu(res.getString("Domaine"));
			e.setProfilIndividu(res.getString("Profil"));
			e.setDomCompetenceIndividu(res.getString("Competence"));
			e.setLangMaternelleIndividu(res.getString("Lang_Maternelle"));
			e.setLangParleIndividu(res.getString("Lang_Parlee"));
			e.setNumTel(res.getString("Telephone"));
			e.setMail(res.getString("Email"));;
			e.setAdresseIndividu(res.getString("Adresse_Etudiant"));
			
		   return e ;	
		}	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	   }
		return null;
	}

	@Override
	public void AjouterEnseignant(Enseignant e) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("INSERT INTO Enseignant VALUES (?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)");
			
			ps.setInt(1, e.getIdIndividu());
			ps.setString(2, e.getNomIndividu());
			ps.setString(3, e.getPrenomIndividu());
			ps.setString(4, e.getGenreIndividu());
			ps.setDate(5, e.getDateNaissIndividu());
			ps.setString(6, e.getLieuNaissIndividu());
			ps.setString(7, e.getNiveauIndividu());
			ps.setString(8, e.getDomEtudeIndividu());
			ps.setString(9, e.getProfilIndividu());
			ps.setString(10, e.getDomCompetenceIndividu());
			ps.setString(11, e.getLangMaternelleIndividu());
			ps.setString(12, e.getLangParleIndividu());
			ps.setString(13, e.getNumTel());
			ps.setString(14, e.getMail());
			ps.setString(15, e.getAdresseIndividu());
 
			
			ps.executeUpdate();
			listEnseignant.add(e) ;
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public Enseignant ModifierEnseignant(Enseignant o) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
	("UPDATE Enseignant SET ID_Enseignant = ?, Nom_Enseignant = ?, Prenom_Enseignant = ?,"
	 + "Genre_Enseignant = ?, Date_Naissance = ?, Lieu_Naissance = ?, Niveau-Enseignant = ?, Domaine_Enseignant = ?,"
	 + "Profil_Enseignant = ?, Domaine_Competence = ?, Lang_Maternelle = ?, Lang_Parlee = ?, "
	 + "Numero_Telephone = ?, Email = ?, Adresse_Enseignant = ?");
			for(Enseignant e : listEnseignant) {
				if(e.getIdIndividu() == o.getIdIndividu()) {
					e.setIdIndividu(o.getIdIndividu());
					e.setNomIndividu(o.getNomIndividu());
					e.setPrenomIndividu(o.getPrenomIndividu());
					e.setGenreIndividu(o.getGenreIndividu());
					e.setDateNaissIndividu(o.getDateNaissIndividu());
					e.setNiveauIndividu(o.getNiveauIndividu());
					e.setDomEtudeIndividu(o.getDomEtudeIndividu());
					e.setPrenomIndividu(o.getProfilIndividu());
					e.setDomCompetenceIndividu(o.getDomCompetenceIndividu());
					e.setLangMaternelleIndividu(o.getLangMaternelleIndividu());
					e.setNumTel(o.getNumTel());
					e.setMail(o.getMail());
					e.setAdresseIndividu(o.getAdresseIndividu());
				}
				return e ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null ;
		 
		 
	}

	@Override
	public void SupprimerEnseignant(int numEnseignant) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete from Enseignant where ID_Enseignant = ?");
			ps.setInt(1, numEnseignant);
			for(Enseignant e : listEnseignant) {
				if(e.getIdIndividu() == numEnseignant) {
					listEnseignant.remove(e) ;
					System.out.println("Enseignant supprimé avec succès");
				}else
					System.out.println("Sorry , id not exist !!!");
			}
			ps.executeUpdate() ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
	}

	@Override
	public List<Enseignant> AfficherAllEnseignant() {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("Select * from Enseignant");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Enseignant e = new Enseignant() ;
				e.setIdIndividu(res.getInt("ID_Enseignant"));
				e.setNomIndividu(res.getString("Nom_Enseignant"));
				e.setPrenomIndividu(res.getString("Prenom_Enseignant"));
				e.setGenreIndividu(res.getString("Genre_Enseignant"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Enseignant"));
				e.setDomEtudeIndividu(res.getString("Domaine_Enseignant"));
				e.setProfilIndividu(res.getString("Profil_Enseignant"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Email"));
				e.setAdresseIndividu(res.getString("Adresse_Enseignant"));
 
				listEnseignant.add(e) ;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return listEnseignant;
	}

	@Override
	public List<Enseignant> RechercherEnseignantMC(String word) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Enseignant where Nom_Enseignant like ?") ;
			ps.setString(1,"%"+word+"%");
			ResultSet res=ps.executeQuery(); 
			while(res.next()){
				List<Enseignant> listE = new ArrayList<>() ;
				Enseignant e = new Enseignant() ;
				e.setIdIndividu(res.getInt("ID_Enseignant"));
				e.setNomIndividu(res.getString("Nom_Enseignant"));
				e.setPrenomIndividu(res.getString("Prenom_Enseignant"));
				e.setGenreIndividu(res.getString("Genre_Enseignant"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Enseignant"));
				e.setDomEtudeIndividu(res.getString("Domaine_Enseignant"));
				e.setProfilIndividu(res.getString("Profil_Enseignant"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Email"));
				e.setAdresseIndividu(res.getString("Adresse_Enseignant"));
				listEnseignant.add(e) ;
				listE.add(e);
				
				return listE;
			    
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listEnseignant ;
	}

	@Override
	public Enseignant RechercherEnseigantantMatricule(int matricule) {
		Connection conn = DataBaseConnection.getConnection() ; 
		Enseignant e = null ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Enseignant where ID_Enseignant = ?");
			ps.setInt(1,matricule);
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				  e = new Enseignant() ;
				e.setIdIndividu(res.getInt("ID_Enseignant"));
				e.setNomIndividu(res.getString("Nom_Enseignant"));
				e.setPrenomIndividu(res.getString("Prenom_Enseignant"));
				e.setGenreIndividu(res.getString("Genre_Enseignant"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Enseignant"));
				e.setDomEtudeIndividu(res.getString("Domaine_Enseignant"));
				e.setProfilIndividu(res.getString("Profil_Enseignant"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Email"));
				e.setAdresseIndividu(res.getString("Adresse_Enseignant"));
				
			     
			}
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return e;
	}
	//****************** GESTION DE COMPTABLE **********************

	@Override
	public void AjouterDirecteur(Directeur e) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("INSERT INTO Directeur VALUES (?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)");

			ps.setInt(1, e.getIdIndividu());
			ps.setString(2, e.getNomIndividu());
			ps.setString(3, e.getPrenomIndividu());
			ps.setString(4, e.getGenreIndividu());
			ps.setDate(5, e.getDateNaissIndividu());
			ps.setString(6, e.getLieuNaissIndividu());
			ps.setString(7, e.getNiveauIndividu());
			ps.setString(8, e.getDomEtudeIndividu());
			ps.setString(9, e.getProfilIndividu());
			ps.setString(10, e.getDomCompetenceIndividu());
			ps.setString(11, e.getLangMaternelleIndividu());
			ps.setString(12, e.getLangParleIndividu());
			ps.setString(13, e.getNumTel());
			ps.setString(14, e.getMail());
			ps.setString(15, e.getAdresseIndividu());
			
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public List<Directeur> RechercherDirecteurMC(String word) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Directeur where ID_Directeur = ?");
			ps.setString(1,"%"+word+"%");
			ResultSet res=ps.executeQuery(); 
			while(res.next()){
				Directeur e = new Directeur() ;
				e.setIdIndividu(res.getInt("ID_Directeur"));
				e.setNomIndividu(res.getString("Nom_Directeur"));
				e.setPrenomIndividu(res.getString("Prenom_Directeur"));
				e.setGenreIndividu(res.getString("Genre_Directeur"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Directeur"));
				e.setDomEtudeIndividu(res.getString("Domaine_Directeur"));
				e.setProfilIndividu(res.getString("Profil_Directeur"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Adresse_Email"));
				e.setAdresseIndividu(res.getString("Adresse_Directeur"));
				listDirecteur.add(e) ;
			    
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listDirecteur;
	}

	@Override
	public Directeur RechercherDirecteurMatricule(int matricule) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Directeur where ID_Directeur = ?");
			ps.setInt(1,matricule);
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				Directeur e = new Directeur() ;
				e.setIdIndividu(res.getInt("ID_Directeur"));
				e.setNomIndividu(res.getString("Nom_Directeur"));
				e.setPrenomIndividu(res.getString("Prenom_Directeur"));
				e.setGenreIndividu(res.getString("Genre_Directeur"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Directeur"));
				e.setDomEtudeIndividu(res.getString("Domaine_Directeur"));
				e.setProfilIndividu(res.getString("Profil_Directeur"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Adresse_Email"));
				e.setAdresseIndividu(res.getString("Adresse_Directeur"));
				
			return e ;    
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Directeur> AfficherAllDirecteur() {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Directeur");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Directeur e = new Directeur() ;
				e.setIdIndividu(res.getInt("ID_Directeur"));
				e.setNomIndividu(res.getString("Nom_Directeur"));
				e.setPrenomIndividu(res.getString("Prenom_Directeur"));
				e.setGenreIndividu(res.getString("Genre_Directeur"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Directeur"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Directeur"));
				e.setProfilIndividu(res.getString("Profil_Directeur"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangParleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Adresse_Email"));;
				e.setAdresseIndividu(res.getString("Adresse_Directeur"));
				listDirecteur.add(e) ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listDirecteur;
	}
	@Override
	public void SupprimerDirecteur(int numDirecteur) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete from Directeur where ID_Directeur = ?");
			ps.setInt(1, numDirecteur);
			for(Directeur e : listDirecteur) {
				if(e.getIdIndividu() ==  numDirecteur) {
					listDirecteur.remove(e) ;
					System.out.println("Directeur supprimé avec succès");
				}else
					System.out.println("Sorry , id not exist !!!");
			}
			ps.executeUpdate() ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
		
	}
	@Override
	public Directeur ModifierDirecteur(Directeur o) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
	("UPDATE Directeur SET ID_Directeur = ?, Nom_Directeur = ?, Prenom_Directeur = ?,"
	 + "Genre_Directeur = ?, Date_Naissance = ?, Lieu_Naissance = ?, Niveau_Directeur = ?, Domaine_Directeur = ?,"
	 + "Profil_Directeur = ?, Domaine_Competence = ?, Lang_Maternelle = ?, Lang_Parlee = ?, "
	 + "Numero_Telephone = ?, Adresse_Email = ?, Adresse_Directeur = ?");
			for(Directeur e : listDirecteur) {
				if(e.getIdIndividu() == o.getIdIndividu()) {
					e.setIdIndividu(o.getIdIndividu());
					e.setNomIndividu(o.getNomIndividu());
					e.setPrenomIndividu(o.getPrenomIndividu());
					e.setGenreIndividu(o.getGenreIndividu());
					e.setDateNaissIndividu(o.getDateNaissIndividu());
					e.setNiveauIndividu(o.getNiveauIndividu());
					e.setDomEtudeIndividu(o.getDomEtudeIndividu());
					e.setPrenomIndividu(o.getProfilIndividu());
					e.setDomCompetenceIndividu(o.getDomCompetenceIndividu());
					e.setLangMaternelleIndividu(o.getLangMaternelleIndividu());
					e.setNumTel(o.getNumTel());
					e.setMail(o.getMail());
					e.setAdresseIndividu(o.getAdresseIndividu());
				}
				return e ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null ;
	}

		
	//***************** GESTION ADMINISTRATEUR ********************

	@Override
	public void AjouterAdministarteur(Administrateur e) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("INSERT INTO Administrateur VALUES (?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)");

			ps.setInt(1, e.getIdIndividu());
			ps.setString(2, e.getNomIndividu());
			ps.setString(3, e.getPrenomIndividu());
			ps.setString(4, e.getGenreIndividu());
			ps.setDate(5, e.getDateNaissIndividu());
			ps.setString(6, e.getLieuNaissIndividu());
			ps.setString(7, e.getNiveauIndividu());
			ps.setString(8, e.getDomEtudeIndividu());
			ps.setString(9, e.getProfilIndividu());
			ps.setString(10, e.getDomCompetenceIndividu());
			ps.setString(11, e.getLangMaternelleIndividu());
			ps.setString(12, e.getLangParleIndividu());
			ps.setString(13, e.getNumTel());
			ps.setString(14, e.getMail());
			ps.setString(15, e.getAdresseIndividu());
			
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public List<Administrateur> RechercherAdministrateurMC(String word) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Administrateur where Nom_Admin like ?");
			ps.setString(1,"%"+word+"%");
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				Administrateur e = new Administrateur() ;
				e.setIdIndividu(res.getInt("ID_Admin"));
				e.setNomIndividu(res.getString("Nom_Admin"));
				e.setPrenomIndividu(res.getString("Prenom_Admin"));
				e.setGenreIndividu(res.getString("Genre_Admin"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Admin"));
				e.setDomEtudeIndividu(res.getString("Domaine_Admin"));
				e.setProfilIndividu(res.getString("Profil_Admin"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Email"));
				e.setAdresseIndividu(res.getString("Adresse_Admin"));
				listAdmin.add(e) ;
			    
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listAdmin;
	}

	@Override
	public Administrateur RechercherAdministrateurMatricule(int matricule) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Administrateur where ID_Admin = ?");
			ps.setInt(1,matricule);
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				Administrateur e = new Administrateur() ;
				 e.setIdIndividu(res.getInt("ID_Admin"));
					e.setNomIndividu(res.getString("Nom_Admin"));
					e.setPrenomIndividu(res.getString("Prenom_Admin"));
					e.setGenreIndividu(res.getString("Genre_Admin"));
					e.setDateNaissIndividu(res.getDate("Date_Naissance"));
					e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
					e.setNiveauIndividu(res.getString("Niveau_Admin"));
					e.setDomEtudeIndividu(res.getString("Domaine_Admin"));
					e.setProfilIndividu(res.getString("Profil_Admin"));
					e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
					e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
					e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
					e.setNumTel(res.getString("Numero_Telephone"));
					e.setMail(res.getString("Email"));
					e.setAdresseIndividu(res.getString("Adresse_Admin"));
				
			  return e ;  
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Administrateur> AfficherAllAdmin() {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Administrateur");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Administrateur e = new Administrateur() ;
				e.setIdIndividu(res.getInt("ID_Admin"));
				e.setNomIndividu(res.getString("Nom_Admin"));
				e.setPrenomIndividu(res.getString("Prenom_Admin"));
				e.setGenreIndividu(res.getString("Genre_Admin"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Admin"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Admin"));
				e.setProfilIndividu(res.getString("Profil_Admin"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangParleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Email"));;
				e.setAdresseIndividu(res.getString("Adresse_Admin"));
				listAdmin.add(e) ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listAdmin;
	}

	@Override
	public void SupprimerAdministrateur(int numAdmin) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete *from Administrateur where ID_Admin = ?");
			ps.setInt(1, numAdmin);
			for(Administrateur e : listAdmin) {
				if(e.getIdIndividu() ==  numAdmin) {
					listAdmin.remove(e) ;
					System.out.println("Comptable supprimé avec succès");
				}else
					System.out.println("Sorry , id not exist !!!");
			}
			ps.executeUpdate() ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 	
	}

	@Override
	public Administrateur ModifierAdmin(Administrateur o) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
	("UPDATE Administrateur SET ID_Admin = ?, Nom_Admin = ?, Prenom_Admin = ?,"
	 + "Genre_Admin = ?, Date_Naissance = ?, Lieu_Naissance = ?, Niveau_Admin = ?, Domaine_Admin = ?,"
	 + "Profil_Admin = ?, Domaine_Competence = ?, Lang_Maternelle = ?, Lang_Parlee = ?, "
	 + "Numero_Telephone = ?, Email = ?, Adresse_Admin = ?");
			for(Administrateur e : listAdmin) {
				if(e.getIdIndividu() == o.getIdIndividu()) {
					e.setIdIndividu(o.getIdIndividu());
					e.setNomIndividu(o.getNomIndividu());
					e.setPrenomIndividu(o.getPrenomIndividu());
					e.setGenreIndividu(o.getGenreIndividu());
					e.setDateNaissIndividu(o.getDateNaissIndividu());
					e.setNiveauIndividu(o.getNiveauIndividu());
					e.setDomEtudeIndividu(o.getDomEtudeIndividu());
					e.setPrenomIndividu(o.getProfilIndividu());
					e.setDomCompetenceIndividu(o.getDomCompetenceIndividu());
					e.setLangMaternelleIndividu(o.getLangMaternelleIndividu());
					e.setNumTel(o.getNumTel());
					e.setMail(o.getMail());
					e.setAdresseIndividu(o.getAdresseIndividu());
				}
				return e ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null ;
	}

	//*************** GESTION DDE SECRETAIRE *********************

	@Override
	public void AjouterSecretaire(Secretaire e) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("INSERT INTO Secretaire VALUES (?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, e.getIdIndividu());
			ps.setString(2, e.getNomIndividu());
			ps.setString(3, e.getPrenomIndividu());
			ps.setString(4, e.getGenreIndividu());
			ps.setDate(5, e.getDateNaissIndividu());
			ps.setString(6, e.getLieuNaissIndividu());
			ps.setString(7, e.getNiveauIndividu());
			ps.setString(8, e.getDomEtudeIndividu());
			ps.setString(9, e.getProfilIndividu());
			ps.setString(10, e.getDomCompetenceIndividu());
			ps.setString(11, e.getLangMaternelleIndividu());
			ps.setString(12, e.getLangParleIndividu());
			ps.setString(13, e.getNumTel());
			ps.setString(14, e.getMail());
			ps.setString(15, e.getAdresseIndividu());
			
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public List<Secretaire> RechercherSecretaireMC(String word) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("Select * from Secretaire where Nom_Secretaire like ?");
			ps.setString(1,"%"+word+"%");
			ResultSet res=ps.executeQuery(); 
			while(res.next()){
				Secretaire e = new Secretaire() ;
				e.setIdIndividu(res.getInt("ID_Secretaire"));
				e.setNomIndividu(res.getString("Nom_Secretaire"));
				e.setPrenomIndividu(res.getString("Prenom_Secretaire"));
				e.setGenreIndividu(res.getString("Genre_Secretaire"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Secretaire"));
				e.setDomEtudeIndividu(res.getString("Domaine_Secretaire"));
				e.setProfilIndividu(res.getString("Profil_Secretaire"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Adresse_Email"));
				e.setAdresseIndividu(res.getString("Adresse_Secretaire"));
				listSecretaire.add(e) ;
			    
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSecretaire;
	}

	@Override
	public Secretaire RechercherSecretaireMatricule(int matricule) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("Select * from Secretaire where ID_Secretaire = ?");
			ps.setInt(1,matricule);
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				 Secretaire e = new Secretaire() ;
				 e.setIdIndividu(res.getInt("ID_Secretaire"));
				 e.setNomIndividu(res.getString("Nom_Secretaire"));
				 e.setPrenomIndividu(res.getString("Prenom_Secretaire"));
			   	 e.setGenreIndividu(res.getString("Genre_Secretaire"));
				 e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				 e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				 e.setNiveauIndividu(res.getString("Niveau_Secretaire"));
				 e.setDomEtudeIndividu(res.getString("Domaine_Secretaire"));
				 e.setProfilIndividu(res.getString("Profil_Secretaire"));
				 e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				 e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				 e.setLangMaternelleIndividu(res.getString("Langue_Parlee"));
				 e.setNumTel(res.getString("Numero_Telephone"));
				 e.setMail(res.getString("Adresse_Email"));
				 e.setAdresseIndividu(res.getString("Adresse_Secretaire"));
				
			  return e;  
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Secretaire> AfficherAllSecretaire() {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("Select * from Secretaire");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Secretaire e = new Secretaire() ;
				e.setIdIndividu(res.getInt("ID_Secretaire"));
				e.setNomIndividu(res.getString("Nom_Secretaire"));
				e.setPrenomIndividu(res.getString("Prenom_Secretaire"));
				e.setGenreIndividu(res.getString("Genre_Secretaire"));
				e.setDateNaissIndividu(res.getDate("Date_Naissance"));
				e.setLieuNaissIndividu(res.getString("Lieu_Naissance"));
				e.setNiveauIndividu(res.getString("Niveau_Secretaire"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Secretaire"));
				e.setProfilIndividu(res.getString("Profil_Secretaire"));
				e.setDomCompetenceIndividu(res.getString("Domaine_Competence"));
				e.setLangMaternelleIndividu(res.getString("Langue_Maternelle"));
				e.setLangParleIndividu(res.getString("Langue_Parlee"));
				e.setNumTel(res.getString("Numero_Telephone"));
				e.setMail(res.getString("Adresse_Email"));;
				e.setAdresseIndividu(res.getString("Adresse_Secretaire"));
				listSecretaire.add(e) ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSecretaire ;
	}

	@Override
	public void SupprimerSecretaire(int numSecretaire) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete *from Secretaire where ID_Secretaire = ?");
			ps.setInt(1, numSecretaire);
			for(Secretaire e : listSecretaire) {
				if(e.getIdIndividu() ==  numSecretaire) {
					listSecretaire.remove(e) ;
					System.out.println("Secretaire supprimé avec succès");
				}else
					System.out.println("Sorry , id not exist in the data base !!!");
			}
			ps.executeUpdate() ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	@Override
	public Secretaire ModifierSecretaire(Secretaire o) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
	("UPDATE  Secretaire SET ID_Secretaire = ?, Nom_Secretaire = ?, Prenom_Secretaire = ?,"
	 + "Genre_Secretaire = ?, Date_Naissance = ?, Lieu_Naissance = ?, Niveau_Secretaire = ?, Domaine_Secretaire = ?,"
	 + "Profil_Secretaire = ?, Domaine_Competence = ?, Lang_Maternelle = ?, Lang_Parlee = ?, "
	 + "Numero_Telephone = ?, Adresse_Email = ?, Adresse_Secretaire = ?");
			for(Secretaire e : listSecretaire) {
				if(e.getIdIndividu() == o.getIdIndividu()) {
					e.setIdIndividu(o.getIdIndividu());
					e.setNomIndividu(o.getNomIndividu());
					e.setPrenomIndividu(o.getPrenomIndividu());
					e.setGenreIndividu(o.getGenreIndividu());
					e.setDateNaissIndividu(o.getDateNaissIndividu());
					e.setNiveauIndividu(o.getNiveauIndividu());
					e.setDomEtudeIndividu(o.getDomEtudeIndividu());
					e.setPrenomIndividu(o.getProfilIndividu());
					e.setDomCompetenceIndividu(o.getDomCompetenceIndividu());
					e.setLangMaternelleIndividu(o.getLangMaternelleIndividu());
					e.setNumTel(o.getNumTel());
					e.setMail(o.getMail());
					e.setAdresseIndividu(o.getAdresseIndividu());
				}
				return e ;
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null ;
	}	

	//***************** GESTION SALLE *****************************

	@Override
	public void AjouterSalle(Salle e) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
				PreparedStatement ps = conn.prepareStatement
						("insert into salle values (?, ?, ?, ?);");
				
				ps.setInt(1, e.getIdSalle());
				ps.setString(2, e.getNomSalle());
				ps.setInt(3, e.getCapaciteSalle());
				ps.setString(4, e.getDisponibiliteSalle());
				ps.executeUpdate();
				listSalle.add(e);
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
		
	}

	@Override
	public void SupprimerSalle(int id) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("delete  from salle where ID_Salle = ? ;");
			ps.setInt(1, id);
			for(Salle s : listSalle) {
				if(s.getIdSalle()== id) {
					listSalle.remove(s);
				}
				else {
					System.out.println("L'id renseigné ne correspond à aucune salle");
				 }
					
				}
		            ps.executeUpdate();
					System.out.println("Succès!!!");		

			ps.close();
		} catch (SQLException e1) {
 
			e1.printStackTrace();
		} 			
	}

	@Override
	public int CapaciteSalle(int id) {
		Connection conn = DataBaseConnection.getConnection();
		int capacite = 0 ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select Capacite_Salle from Salle where ID_Salle = ?");
			ps.setInt(1,id);
			ResultSet res=ps.executeQuery(); 
			if(res.next()){
				 capacite = res.getInt("Capacite_Salle");
			}
			ps.close();
		} catch (SQLException e) {
 			
			e.printStackTrace();
		}
		return capacite;
	}

	@Override
	public List<Salle> ChercherSalle(int capacite) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select *from Salle where Capacite_Salle = ?") ;
			ps.setInt(1, capacite);
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Salle s = new Salle();
				s.setIdSalle(res.getInt("ID_Salle"));
				s.setNomSalle(res.getString("Nom_Salle"));
				s.setCapaciteSalle(res.getInt("Capacte_Salle"));
				s.setDisponibiliteSalle(res.getString("Disponibilite"));
				listSalle.add(s) ;
			}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSalle;
	}

	@Override
	public List<Salle> AfficherSalle() {
		Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					               ("Select * from Salle");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Salle e = new Salle() ;
				e.setIdSalle(res.getInt("ID_Salle"));
				e.setNomSalle(res.getString("Nom_Salle"));
				e.setCapaciteSalle(res.getInt("Capacite_Salle"));
				e.setDisponibiliteSalle(res.getString("Disponibilite"));
				listSalle.add(e) ;
				}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return listSalle;
		 
	}

	@Override
	public List<Integer> ChargerSalle() {
		List <Integer> listsa = new ArrayList<>();
		Connection conn = DataBaseConnection.getConnection();
		
		
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement("Select * from Salle");
			
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				Salle e = new Salle();
				int id =res.getInt("ID_Salle");
				/*e.setNomSalle(res.getString("Nom_Salle"));
				e.setCapaciteSalle(res.getInt("Capacite_Salle"));
				e.setDisponibiliteSalle(res.getString("Disonibilite"));*/
				listsa.add(id);
			}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		
		

		return listsa;
	}

	//************** GESTION DE LA SESSION ***********************

	@Override
	public void AjouterSession(Session e) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("insert into Sessions values (?, ?, ?, ? , ?);");
			
			ps.setInt(1, e.getIdSession());
			ps.setInt(2, e.getAnneeSession());
			ps.setString(3, e.getNomSession());
			ps.setDate(4, (Date) e.getDateDebutSession());
			ps.setDate(5, (Date) e.getDateFinSession());
			ps.executeUpdate();
			listSession.add(e);
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 	
	}

	@Override
	public void SupprimerSession(int id) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("delete * from Sessions where ID_Session = ? ;");
			ps.setInt(1, id);
			for(Session s : listSession) {
				if(s.getIdSession()== id) {
					listSession.remove(s);
					ps.executeUpdate();
					System.out.println("Succès!!!");
				}else {
					System.out.println("L'id renseigné ne correspond à aucune session");
				}
			}
						
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
	}

	@Override
	public List<Session> AfficherSession() {
		Connection conn = DataBaseConnection.getConnection();
		 try {
				PreparedStatement ps = conn.prepareStatement
						               ("Select * from Sessions");
				ResultSet res = ps.executeQuery() ;
				while(res.next()) {
					Session e = new Session() ;
					e.setIdSession(res.getInt("ID_Session"));
					e.setAnneeSession(res.getInt("ID_Annee"));
					e.setNomSession(res.getString("Nom_Session"));
					e.setDateDebutSession(res.getDate("Date_Debut_Session"));
					e.setDateFinSession(res.getDate("Date_Fin_Session"));
					listSession.add(e) ;
					}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return listSession;
	}

	@Override
	public List<Integer> ChargerSession() {
		List <Integer> listSes= new ArrayList<>();
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Sessions");
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				Session e = new Session();
				int id =res.getInt("ID_Session");
				
				listSes.add(id);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listSes;
 
	}

	@Override
	public void AjouterInscription(Inscription e, int idEtudiant, int idSession, int idGroupe, int idPaiement) {
		 Connection conn = DataBaseConnection.getConnection() ;
			try {
				PreparedStatement ps = conn.prepareStatement
						("insert into Inscription values (?, ?, ?, ?, ?,?);");
			
				ps.setInt(1, e.getIdInscription());
				ps.setInt(2, e.getEtudiant().getIdIndividu());
				ps.setInt(3, e.getGroupe().getIdGroupe());
				ps.setInt(4, e.getSession().getIdSession());
				ps.setInt(5, e.getPaiement().getIdpaiement());
				ps.setDate(6, (Date) e.getDateInscription());;
				ps.executeUpdate();
				listInscris.add(e);
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
	}

	@Override
	public List<Inscription> AfficherInscription() {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Incription");
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				Inscription e = new Inscription();
				e.setIdInscription(res.getInt(1));
				int idEtudiant = res.getInt(2);
				e.setDateInscription(res.getDate(3));
				int idSession = res.getInt(4);
				int idGroupe = res.getInt(5);
				int idPaiement = res.getInt(6);
				PreparedStatement ps1 = conn.prepareStatement("select * from Etudiant where ID_Etudiant =?");
				ps1.setInt(1, idEtudiant);
				ResultSet res1 = ps1.executeQuery();
				if (res1.next()) {
					Etudiant etude = new Etudiant();
					etude.setIdIndividu(res1.getInt(1));
					e.setEtudiant(etude);
					ps1.close();
				}
				PreparedStatement ps2 = conn.prepareStatement("select * from Sessions where ID_Session =?");
				ps2.setInt(1, idSession);
				ResultSet res2 = ps2.executeQuery();
				if (res2.next()) {
					Session s = new Session();
					s.setIdSession(res2.getInt(1));
					e.setSession(s);
					ps2.close();
				}
				PreparedStatement ps3 = conn.prepareStatement("select * from Groupe where ID_Groupe =?");
				ps3.setInt(1, idGroupe);
				ResultSet res3 = ps3.executeQuery();
				if (res3.next()) {
					Groupe g = new Groupe();
					g.setIdGroupe(res3.getInt(1));
					e.setGroupe(g);
					ps3.close();
				}
				PreparedStatement ps4 = conn.prepareStatement("select * from Paiement where ID_Paiement =?");
				ps4.setInt(1, idPaiement);
				ResultSet res4 = ps4.executeQuery();
				if (res4.next()) {
					Paiement p = new Paiement();
					p.setIdpaiement(res4.getInt(1));
					e.setPaiement(p);
					ps4.close();
				}

				listInscris.add(e);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return listInscris;
	}

	@Override
	public void AjouterGroupe(Groupe e, int idHoraire, int idSession, int idSalle, int idModule) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("INSERT INTO Groupe VALUES (?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, e.getIdGroupe());
			ps.setString(2, e.getNomGroupe());
			ps.setDate(3, (Date) e.getDateExamen());
			ps.setInt(4, idHoraire);
			ps.setInt(5, idSession);
			ps.setInt(6, idSalle);
			ps.setInt(7, idModule);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
 
	@Override
	public void SupprimerGroupe(int id) {
		 Connection conn = DataBaseConnection.getConnection() ;
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete from Groupe where ID_Groupe = ?");
			ps.setInt(1, id);
			for(Groupe g : listGroupe) {
				if(g.getIdGroupe() == id) {
					listGroupe.remove(g);
					System.out.println("Suppression effectué avec succès");
				}else
					System.out.println("Id inconnu , sorry !!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
 
	@Override
	public List<Groupe> AfficherGroupe() {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Groupe");
			ResultSet res = ps.executeQuery();
			while(res.next()) {
				Groupe g = new Groupe();
				g.setIdGroupe(res.getInt("ID_Groupe"));
				g.setNomGroupe(res.getString("Nom_Groupe"));
				int idHoraire = res.getInt("ID_Horaire");
				int idSession = res.getInt("ID_Session");
				int idSalle = res.getInt("ID_Salle");
				int idModule = res.getInt("ID_Module");
				PreparedStatement ps1 = conn.prepareStatement
						("Select *from Horaire where ID_Horaire = ?");
				ps1.setInt(1, idHoraire);
				ResultSet res1 = ps1.executeQuery();
				if(res1.next()) {
					Horaire h = new Horaire () ;
					h.setIdHoraire(res1.getInt("ID_Horaire"));
					g.setHoraire(h);
				}
				PreparedStatement ps2 = conn.prepareStatement
						("Select * from Session where ID_Session = ?");
				ps.setInt(1, idSession);
				ResultSet res2 = ps2.executeQuery() ;
				if(res2.next()) {
					Session s = new Session ();
					s.setIdSession(res2.getInt("ID_Session"));
					g.setSession(s);
				}
				PreparedStatement ps3 = conn.prepareStatement
						("Select * from Salle where ID_Salle = ?");
				ps3.setInt(1, idSalle);
				ResultSet res3 = ps3.executeQuery();
				if(res3.next()) {
					Salle sal = new Salle () ;
					sal.setIdSalle(res3.getInt("ID_Salle"));
					g.setSalle(sal);
				}
				PreparedStatement ps4 = conn.prepareStatement
						("Select * from Module where ID_Module = ?");
				ps4.setInt(1, idModule);
				ResultSet res4 = ps4.executeQuery();
				if(res4.next()) {
					Module mod = new Module ();
					mod.setIdModule(res4.getInt("ID_Module"));
					g.setModule(mod);
					
				}
				listGroupe.add(g);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listGroupe;
	}
	//****************** GESTION DE MATIERE ******************************

	@Override
	public void AjouterMatiere(Matiere e, int numModule) {
		 Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("Insert into Matiere Values (?, ?, ?, ?, ?, ?) ;") ;
			ps.setInt(1, e.getIdMatiere());
			ps.setString(2, e.getNomMatiere());
			ps.setString(3, e.getLibelleMatiere());
			ps.setString(4, e.getLangLibelleMatiere());
			ps.setString(5, e.getNivMatiere());
			ps.setInt(6, e.getModule().getIdModule());
			
		ps.close();
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void SuppridmerMatiere(int id) {
		 Connection conn = DataBaseConnection.getConnection() ;
		 try {
			PreparedStatement ps = conn.prepareStatement
					 ("delete from Matiere where ID_Matiere = ?");
			ps.setInt(1, id);
			for(Matiere m : listMatiere) {
				if(m.getIdMatiere() == id) {
					listMatiere.remove(m);
					System.out.println("Suppression effectué avec succès");
				}else
					System.out.println("Id inconnu , sorry !!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public List<Matiere> AfficherMatiere() {
		Connection conn = DataBaseConnection.getConnection();
		 try {
			PreparedStatement ps = conn.prepareStatement
					               ("Select * from Matiere");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
				Matiere e = new Matiere() ;
				e.setIdMatiere(res.getInt("ID_Matiere"));
				e.setNomMatiere(res.getString("Nom_Matiere"));
				e.setLibelleMatiere(res.getString("Libele_Matiere"));
				e.setLangLibelleMatiere(res.getString("Lang_Libele_Matiere"));
				e.setNivMatiere(res.getString("Niveau_Matiere"));
				int idModule = res.getInt("ID_Module");
				PreparedStatement ps2 = conn.prepareStatement
						   ("Select * from Module where ID_Module = ?"); 
				
				ps2.setInt(1, idModule);
				ResultSet res2 = ps2.executeQuery();
				if(res2.next()) {
					Module m = new Module ();
					m.setIdModule(res2.getInt("ID_Module"));
					e.setModule(m);
				}
				listMatiere.add(e) ;
				ps2.close();
				}
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return listMatiere;
		
	}
	

	//***************** GSET DE MODULE  ***********************************

	@Override
	public void AjouterModule(Module e) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("INSERT INTO Module Values(?, ?)") ;
			ps.setInt(1, e.getIdModule());
			ps.setString(2, e.getlibeleModole());
			ps.executeUpdate() ;
			
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void SupprimerModule(int id) {
		Connection conn = DataBaseConnection.getConnection() ;
		try {
			PreparedStatement ps = conn.prepareStatement
					("delete * from Module where ID_Module = ? ;");
			ps.setInt(1, id);
			for(Module m : listModule) {
				if(m.getIdModule()== id) {
					listModule.remove(m);
					ps.executeUpdate();
					System.out.println("Succès!!!");
				}else {
					System.out.println("L'id renseigné ne correspond à aucune Module");
				}
			}
						
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
		
	}

	@Override
	public List<Module> AfficherModule() {
		Connection conn = DataBaseConnection.getConnection();
		 try {
				PreparedStatement ps = conn.prepareStatement
						               ("Select * from Module");
				ResultSet res = ps.executeQuery() ;
				while(res.next()) {
					Module e = new Module() ;
					e.setIdModule(res.getInt("ID_Module"));
					e.setlibeleModole(res.getString("Libele_Module"));
					listModule.add(e) ;
					}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return listModule;
	}
	@Override
	public List<Integer> ChargerModule() {
		List <Integer> listMod = new ArrayList<>();
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Module");
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				Module e = new Module();
				int id =res.getInt("ID_Module");
				
				listMod.add(id);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listMod;

	}

	//********************* GESTION NOTES *********************************
	

	@Override
	public void AjouterNotes(NotesEtudiant e, int idEtudiant, int idMatiere) {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("insert into Note values (?, ?, ?);");
            
			ps.setInt(1, idEtudiant);
			ps.setInt(2, idMatiere);
			ps.setDouble(3, e.getNote());
			ps.executeUpdate();
			listNotes.add(e);
			ps.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
	}

	@Override
	public List<NotesEtudiant> AfficherNotes() {
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Note");
			ResultSet res = ps.executeQuery();
			if (res.next()) {
				NotesEtudiant e = new NotesEtudiant();
				e.setNote(res.getDouble("Note"));
				int idEtudiant = res.getInt("ID_Etudiant");
				int idMatiere = res.getInt("ID_Matiere");
				PreparedStatement ps2 = conn.prepareStatement("Select * from Etudiant where ID_Etudiant = ?");

				ps2.setInt(1, idEtudiant);
				ResultSet res2 = ps2.executeQuery();
				if (res2.next()) {
					Etudiant m = new Etudiant();
					m.setIdIndividu(res2.getInt("ID_Etudiant"));
					e.setEtudiant(m);
				}

				PreparedStatement ps3 = conn.prepareStatement("Select * from Matiere where ID_Matiere = ?");

				ps3.setInt(1, idMatiere);
				ResultSet res3 = ps3.executeQuery();
				if (res3.next()) {
					Matiere mat = new Matiere();
					mat.setIdMatiere(res3.getInt("ID_Matiere"));
					e.setMatiere(mat);
				}
				listNotes.add(e);
				ps2.close();
				ps3.close();
			}
			ps.close();
		} catch (SQLException e) {
 			e.printStackTrace();
		}

		return listNotes;

	}

	@Override
	public NotesEtudiant RechercheNotes(int idEtud) {
		NotesEtudiant e = null;
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Note where ID_Etudiant = ?");
			ps.setInt(1, idEtud);
			ResultSet res = ps.executeQuery();
			if (res.next()) {
				e = new NotesEtudiant();
				e.setNote(res.getDouble("Note"));
				int idEtudiant = res.getInt("ID_Etudiant");
				int idMatiere = res.getInt("ID_Matiere");
				PreparedStatement ps2 = conn.prepareStatement("Select * from Etudiant where ID_Etudiant = ?");

				ps2.setInt(1, idEtudiant);
				ResultSet res2 = ps2.executeQuery();
				if (res2.next()) {
					Etudiant m = new Etudiant();
					m.setIdIndividu(res2.getInt("ID_Etudiant"));
					e.setEtudiant(m);
				}

				PreparedStatement ps3 = conn.prepareStatement("Select * from Matiere where ID_Matiere = ?");

				ps3.setInt(1, idMatiere);
				ResultSet res3 = ps3.executeQuery();
				if (res3.next()) {
					Matiere m = new Matiere();
					m.setIdMatiere(res3.getInt("ID_Matiere"));
					e.setMatiere(m);
				}
				// listNotes.add(e) ;
				ps2.close();
				ps3.close();
			}
			ps.close();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

		return e;

	}

	@Override
	public Double MoyenneNotes(int idEtudiant) {
		NotesEtudiant e = null;
		double somme = 0;
		int nbre = 0;
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from Note where ID_Etudiant = ?");
			ps.setInt(1, idEtudiant);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				e = new NotesEtudiant();
				somme += res.getDouble("Note");
				nbre++;
			}
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return (somme / nbre);

	}

	@Override
	public void AffecterEnseignant(Enseignant e, int id) {
		 
		
	}

	@Override
	public List<Enseignant_Matiere> AfficherEnseignantAffecter() {
	
		Connection conn = DataBaseConnection.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Enseignant_Matiere");
			ResultSet res = ps.executeQuery() ;
			while(res.next()) {
		    	Enseignant_Matiere e1 = new  Enseignant_Matiere () ;
                e1.setNbHeure(res.getString("Nombre_Heure"));
                int idEnseignant = res.getInt("ID_Enseignant");
                int idMatiere = res.getInt("ID_Matiere") ;
                
                PreparedStatement ps2 = conn.prepareStatement
                		              ("Select * from Enseignant where ID_Enseignant = ?");
                ResultSet res2 = ps2.executeQuery();
                ps2.setInt(1, idEnseignant);
                if(res2.next()){
                	Enseignant en = new Enseignant ();
                	en.setIdIndividu(res2.getInt("ID_Enseignant"));
                	e1.setEnseignant(en);
                	PreparedStatement ps3 = conn.prepareStatement("Select * from Matiere where ID_Matiere = ?");
                    ResultSet res3 = ps2.executeQuery();
                    ps.setInt(1, idMatiere);
                    if(res3.next()) {
                    	Matiere m = new Matiere () ;
                    	m.setIdMatiere(res3.getInt("ID_Matiere"));
                    	e1.setMatiere(m) ;
                    	listEnsMat.add(e1);
                    	
                    }
                    ps3.close();
                	
                }
                ps2.close();
  
			}
            ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listEnsMat;

 
	}


}
