package coucheControler;

public interface JFXButton {

}
