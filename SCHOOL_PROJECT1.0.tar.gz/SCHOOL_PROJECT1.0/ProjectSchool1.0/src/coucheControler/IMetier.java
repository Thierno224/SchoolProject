package coucheControler;

import java.util.List;

import partieConsole.Administrateur;
 
import partieConsole.Directeur;
import partieConsole.Enseignant;
import partieConsole.Enseignant_Matiere;
import partieConsole.Etudiant;
import partieConsole.Groupe;
import partieConsole.Inscription;
import partieConsole.Matiere;
import partieConsole.Module;
import partieConsole.NotesEtudiant;
import partieConsole.Salle;
import partieConsole.Secretaire;
import partieConsole.Session;

public interface IMetier {
 
	//************ETUDIANT*************************************
	public void AjouterEtudiant(Etudiant e);
	public Etudiant ModifierEtudiant(Etudiant o);
	public void SupprimerEtudiant(int idEtudiant);
	public List<Etudiant> AfficherAllEtudiant();
	public List<Etudiant> RechercherEtudiantMC(String word);
	public Etudiant RechercherEtudiantMatricule(int matricule);
	 
	
	//************ENSEIGNANT************************************
	
	public void AjouterEnseignant(Enseignant e);
	public Enseignant ModifierEnseignant(Enseignant o);
	public void SupprimerEnseignant(int numEnseignant);
	public List<Enseignant> AfficherAllEnseignant();
	public List<Enseignant> RechercherEnseignantMC(String word);
	public Enseignant RechercherEnseigantantMatricule(int matricule);
	
	//**************** DIRECTEUR ********************************
	
	public void AjouterDirecteur(Directeur e) ;
	public List<Directeur> RechercherDirecteurMC(String word);
	public Directeur RechercherDirecteurMatricule(int matricule);
	public List<Directeur> AfficherAllDirecteur();
	public void SupprimerDirecteur(int numDirecteur) ;
	public Directeur ModifierDirecteur(Directeur o) ;
	
	//*********** GESTION ADMINISTRATEUR************************
	
	public void AjouterAdministarteur(Administrateur e);
	public List<Administrateur> RechercherAdministrateurMC(String word);
	public Administrateur RechercherAdministrateurMatricule(int matricule); 
	public List<Administrateur> AfficherAllAdmin();
	public void SupprimerAdministrateur(int numAdmin) ;
	public Administrateur ModifierAdmin(Administrateur o);
	
	//********** GESTION DE SECRETAIRE *************************
	
	public void AjouterSecretaire(Secretaire e);
	public List<Secretaire> RechercherSecretaireMC(String word);
	public Secretaire RechercherSecretaireMatricule(int matricule);
	public List<Secretaire> AfficherAllSecretaire();
	public void SupprimerSecretaire(int numSecretaire) ;
	public Secretaire ModifierSecretaire(Secretaire o);
	
	//********* GESTION SALLE  *********************************
	
	public void AjouterSalle(Salle e) ;
	public void SupprimerSalle(int id) ;
	public int CapaciteSalle(int id) ;
	public List <Salle> AfficherSalle() ;
	public List<Salle> ChercherSalle(int capacite) ;
	public List<Integer> ChargerSalle() ;
	
	//******** GESTION DE LA SESSION ****************************
	
	public void AjouterSession(Session e) ;
	public void SupprimerSession(int id) ;
	public List <Session> AfficherSession() ;
	public List<Integer> ChargerSession() ;
	
	//*********** GESTION D'INSCRIPTION *************************
	
	public void AjouterInscription(Inscription e , int idEtudiant, int idSession, int idGroupe, int idPaiement);
	public List<Inscription> AfficherInscription() ;
	
	//********** GESTION GROUPE *********************************
	
	public void AjouterGroupe(Groupe e, int idHoraire, int idSession, int idSalle, int idModule) ;
	public void SupprimerGroupe(int id) ;
	public List <Groupe> AfficherGroupe() ;
	
	//********* GESTION DE MATIERE ******************************
	
	public void AjouterMatiere(Matiere e, int numModule) ;
	public void SuppridmerMatiere(int id) ; 
	public  List<Matiere> AfficherMatiere() ;
	
	//************ GSETION DE MODULE ****************************
	
	public void AjouterModule(Module e) ;
	public void SupprimerModule(int id) ;
	public List <Module> AfficherModule() ;
	public List<Integer> ChargerModule() ;
	
	//************ GSETION DE NOTES ****************************
	
	public void AjouterNotes(NotesEtudiant e, int idEtudiant, int idMatiere);
	public List<NotesEtudiant> AfficherNotes() ;
	public NotesEtudiant RechercheNotes(int idEtud) ;
	public Double MoyenneNotes(int idEtudiant) ;
	
	//******************* Affectation Enseignant **************************
	
	public void AffecterEnseignant (Enseignant e , int id) ;
	public List <Enseignant_Matiere> AfficherEnseignantAffecter() ;
	
    
 }
