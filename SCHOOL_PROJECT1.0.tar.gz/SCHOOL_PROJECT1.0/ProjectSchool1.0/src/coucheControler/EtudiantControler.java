package coucheControler;

import javafx.fxml.FXML;

public class EtudiantControler {
	
	   @FXML
	    private JFXButton buttonAjouter;

	    @FXML
	    private JFXButton buttonModifier;

	    @FXML
	    private JFXButton buttonValider;

	    @FXML
	    private JFXButton buttonAnnuler;


}
