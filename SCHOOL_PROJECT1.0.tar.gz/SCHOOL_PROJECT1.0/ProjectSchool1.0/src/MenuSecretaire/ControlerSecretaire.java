package MenuSecretaire;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ControlerSecretaire implements Initializable {
	
	 @FXML
	    private JFXButton btDeconnexion;

	    @FXML
	    private JFXButton bMenuEtudiant;

	    @FXML
	    private JFXButton bMenuEnseignant;

	    @FXML
	    private JFXButton bMenuSalle;

	    @FXML
	    private JFXButton bMenuMat;

	    @FXML
	    private JFXButton bMenuGroupe;

	    @FXML
	    private JFXButton bMenuSession;

	    @FXML
	    private JFXButton bMenuInscription;
	    
	    @FXML
	    private JFXButton bMenuNotes;

	    @FXML
	    void Deconnexion(ActionEvent event) {

	    }

	    @FXML
	    void MenuEnseignant(ActionEvent event) throws IOException {
	    	Parent pageInscription = FXMLLoader.load(getClass().getResource("/GestionEnseignant/FXMLEnseignant.fxml"));
	        Scene scene = new Scene(pageInscription);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuEtudiant(ActionEvent event) throws IOException {
	    	Parent pageInscription = FXMLLoader.load(getClass().getResource("/GestionEtudiant/FXMLEnseignant.fxml"));
	        Scene scene = new Scene(pageInscription);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuGroupe(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/SeesionGroupe/PageSessionGroupe.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuInscription(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/PageInscription/ViewTransition.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuMat(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/MatiereSession/Page_Matiere_Module.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuSalle(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/MatiereSession/Page_Matiere_Module.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show(); 

	    }
	    
	    @FXML
	    void MenuNotes(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/MenuNotesSecretaire/FXMLNotes.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

	    @FXML
	    void MenuSession(ActionEvent event) throws IOException {
	    	Parent page = FXMLLoader.load(getClass().getResource("/SeesionGroupe/PageSessionGroupe.fxml"));
	        Scene scene = new Scene(page);
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.hide();
            stage.setScene(scene);
            stage.show();

	    }

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			
		}

}
