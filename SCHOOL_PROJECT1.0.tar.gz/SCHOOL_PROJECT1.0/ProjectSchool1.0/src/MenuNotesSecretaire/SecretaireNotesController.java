package MenuNotesSecretaire;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mysql.jdbc.Connection;

import MenuEtudiant.MenuEtudiantController;
import coucheControler.DataBaseConnection;
import coucheControler.Metier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import partieConsole.Etudiant;
import partieConsole.Matiere;
import partieConsole.NotesEtudiant;

public class SecretaireNotesController {
	Connection conexion ;
	
    @FXML
    private AnchorPane pan1;

    @FXML
    private AnchorPane pan2;

    @FXML
    private AnchorPane pan3;

    @FXML
    private TextField idMatier;

    @FXML
    private  TextField idEtudiant;

    @FXML
    private TextField idNote;


    @FXML
    private Button annuleAjout;

    @FXML
    private AnchorPane pan5;

    @FXML
    private AnchorPane pan6;

    @FXML
    private AnchorPane pan4;
    @FXML
    private Button idAjouterNote;

    @FXML
    private Button idAd;

    @FXML
    private TextField IdSupNote;
    @FXML
    private Button idButtonSuppNotes;

    @FXML
    private TableView<NotesEtudiant> Table;

    @FXML
    private TableColumn<NotesEtudiant, Integer> idMat;

    @FXML
    private TableColumn<NotesEtudiant, Integer> idEtud;

    @FXML
    private TableColumn<NotesEtudiant, Integer> idNotesEtud;

    @FXML
    private BarChart< String , Integer> idBarchar;

    @FXML
    private Button barcharbutton;
    
    @FXML
    private Button idStat1;
    @FXML
    private PieChart piechart ;

    @FXML
    void removeAjout(ActionEvent event) {
    	System.exit(0); 

    }
    Metier m = new Metier() ;
     private ObservableList<NotesEtudiant> observableArrayList = FXCollections.observableArrayList();
    
     @FXML
     void AfficheNotes(ActionEvent event) {
     	observableArrayList = FXCollections.observableArrayList(m.AfficherNotes());
    	
        idMat.setCellValueFactory(new PropertyValueFactory<>("etudiant"));
        idEtud.setCellValueFactory(new PropertyValueFactory<>("matiere"));
        idNotesEtud.setCellValueFactory(new PropertyValueFactory<>("note"));
        
        Table.setItems(observableArrayList);
     }
     @FXML
     void RechercherNote(ActionEvent event) {
    	 NotesEtudiant n = new NotesEtudiant() ;
    	 int id = Integer.parseInt(IdSupNote.getText());
    	 n = m.RechercheNotes(id) ;
    	 observableArrayList.add(n) ;
         idMat.setCellValueFactory(new PropertyValueFactory<>("etudiant"));
         idEtud.setCellValueFactory(new PropertyValueFactory<>("matiere"));
         idNotesEtud.setCellValueFactory(new PropertyValueFactory<>("note"));
         Table.setItems(observableArrayList);

     }
     
     @FXML
     void ActionStatistic1(ActionEvent event) {
	        String query = "Select * from Note" ;
	    	
	         XYChart.Series<String, Integer> series = new XYChart.Series<>();
              
	        
	         
	         try {
	        	 
	            conexion = seConnecter();
	        	 
				ResultSet res = conexion.createStatement().executeQuery(query) ;
				while(res.next()) {
					series.getData().add(new XYChart.Data<>(res.getString(1), res.getInt(2)));
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	         idBarchar.getData().add(series); 
   

     }


    @FXML
    void AjouterNote(ActionEvent event) {
 
    	  int idM = Integer.parseInt(idMat.getText());
         int idEtudian = Integer.parseInt(idEtud.getText());
      	int note = Integer.parseInt(idNote.getText());
      	
       
    }

    private Connection seConnecter() {
    	
    	Connection conn = (Connection) DataBaseConnection.getConnection() ;
    	try {
			PreparedStatement ps = conn.prepareStatement
					("Select * from Note") ;
			ps.executeQuery() ;
			System.out.println("hhhhhhhhhhhhhhhhhhhhhh");
			return conn;
		} catch (SQLException e) {
		Logger.getLogger(MenuEtudiantController.class.getName()).log(Level.SEVERE, null , e);
			e.printStackTrace();
		}
		return null;
    	
    }
}
