package MenuEtudiant;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.Connection;

import coucheControler.DataBaseConnection;
import coucheControler.Metier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
 
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
 import partieConsole.NotesEtudiant;

public class MenuEtudiantController {
	Connection conexion ;
	  @FXML
	    private AnchorPane pan1;

	    @FXML
	    private AnchorPane pan2;

	    @FXML
	    private AnchorPane pan6;
 

	    @FXML
	    private TableView<NotesEtudiant> Table;

	    @FXML
	    private TableColumn<NotesEtudiant , Integer> idMat;

	    @FXML
	    private TableColumn<NotesEtudiant , Integer> idEtud;

	    @FXML
	    private TableColumn<NotesEtudiant , Integer> idNotesEtud;

	    @FXML
	    private BarChart< String , Integer> idBarchar;

	    @FXML
	    private JFXTextField idText;
 

	    @FXML
	    private JFXButton statistic;
	    @FXML
	    private Button bttonAffiche;
		
	    private ObservableList<NotesEtudiant> observableArrayList = FXCollections.observableArrayList();
	    private ObservableList<NotesEtudiant> observableArrayList2 = FXCollections.observableArrayList();

	    Metier m = new Metier() ;
    	 

	    @FXML
	    void GetAll(ActionEvent event) {
	    	observableArrayList = FXCollections.observableArrayList(m.AfficherNotes());
	    	
	        idMat.setCellValueFactory(new PropertyValueFactory<>("etudiant"));
	        idEtud.setCellValueFactory(new PropertyValueFactory<>("matiere"));
	        idNotesEtud.setCellValueFactory(new PropertyValueFactory<>("note"));
	        Table.setItems(observableArrayList);

	    }
	    @FXML
	    void ClickMe(ActionEvent event) {
	        String query = "Select * from Note" ;
	
	         XYChart.Series<String, Integer> series = new XYChart.Series<>();
               
	        
	         
	         try {
	        	 
	            conexion = seConnecter();
	        	 
				ResultSet res = conexion.createStatement().executeQuery(query) ;
				while(res.next()) {
					series.getData().add(new XYChart.Data<>(res.getString(1), res.getInt(2)));
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	         idBarchar.getData().add(series);
	    }   
	    private Connection seConnecter() {
	    	
	    	Connection conn = (Connection) DataBaseConnection.getConnection() ;
	    	try {
				PreparedStatement ps = conn.prepareStatement
						("Select * from Note") ;
				ps.executeQuery() ;
				System.out.println("hhhhhhhhhhhhhhhhhhhhhh");
				return conn;
			} catch (SQLException e) {
			Logger.getLogger(MenuEtudiantController.class.getName()).log(Level.SEVERE, null , e);
				e.printStackTrace();
			}
			return null;
	    	
	    }

}
