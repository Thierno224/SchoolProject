-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Lun 16 Avril 2018 à 00:35
-- Version du serveur :  5.7.21-0ubuntu0.16.04.1
-- Version de PHP :  7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Bibliotheque`
--
CREATE DATABASE IF NOT EXISTS `Bibliotheque` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Bibliotheque`;

-- --------------------------------------------------------

--
-- Structure de la table `BandeDessinee`
--

CREATE TABLE `BandeDessinee` (
  `Numero` int(11) NOT NULL,
  `Titre` varchar(50) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `NombrePage` int(11) DEFAULT NULL,
  `Auteur` varchar(30) DEFAULT NULL,
  `Dessinateur` varchar(40) DEFAULT NULL,
  `Comentaire` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `BandeDessinee`
--

INSERT INTO `BandeDessinee` (`Numero`, `Titre`, `Prix`, `NombrePage`, `Auteur`, `Dessinateur`, `Comentaire`) VALUES
(1, 'Mange ', 5, 300, 'Alberto petit ', 'Jul William ', 'Pays d origine France '),
(2, 'Regarder les enfants grandir ', 6, 450, 'DIALLO Thierno ', 'Le Roi Spaic ', 'Origine Guinée '),
(3, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(4, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(5, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(6, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(7, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(8, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(9, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge '),
(10, 'Achille et Boule-de-Gomme ', 20.25, 250, 'Maurice Tullie ', 'Maurice Tullie', 'Origine Bilge ');

-- --------------------------------------------------------

--
-- Structure de la table `Document`
--

CREATE TABLE `Document` (
  `Numero` smallint(5) UNSIGNED NOT NULL,
  `Nom` varchar(30) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `commentaires` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Document`
--

INSERT INTO `Document` (`Numero`, `Nom`, `Prix`, `commentaires`) VALUES
(1, 'Document 1 ', 25.2, 'Creation de mon premier document de la bibliotheque'),
(2, 'Document 2 ', 15, 'Creation de mon, deuxaieme document de la bibliotheque');

-- --------------------------------------------------------

--
-- Structure de la table `Livre`
--

CREATE TABLE `Livre` (
  `Numero` int(11) NOT NULL,
  `Titre_Livre` varchar(50) DEFAULT NULL,
  `Prix_Livre` double DEFAULT NULL,
  `NombrePage` int(11) DEFAULT NULL,
  `Auteur` varchar(30) DEFAULT NULL,
  `Commentaire` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Livre`
--

INSERT INTO `Livre` (`Numero`, `Titre_Livre`, `Prix_Livre`, `NombrePage`, `Auteur`, `Commentaire`) VALUES
(1, 'Le roi du kahel', 15, 450, 'Thierno Mo Nenembo', 'Originaire de la Guinee'),
(2, 'Le monde s effondre', 12, 600, 'Chinua Achebe', 'Originaire du nigeria'),
(3, 'Contes', 30, 500, 'Andesen Christian', 'Originaire du Danemark'),
(4, 'Orgueil et Préjugés', 24, 300, 'Jean Austen', 'Originaire du Royaume Unie'),
(5, 'Le père Goriot', 17, 450, 'Honoré de Balzac', 'Originaire de la France'),
(6, 'Décaméron', 15, 350, 'Boccace', 'Originaire de Italie'),
(7, 'L\'Etranger', 16, 450, 'Alber Camus', 'Originaire de la France'),
(8, 'Voyage au bout de la nuit', 17, 450, 'Louis Ferdinand', 'Originaire de la France'),
(9, 'L\'Enfant noir', 16, 250, 'Camara Laye', 'Originaire de la Guinee'),
(10, 'Le Ventre de l attlentique', 15, 450, 'Fatou Djome', 'Originaire du Sénégal'),
(11, 'Apprenez à programmer en java', 45, 600, 'Cyrille Herby', 'Livre de Open Classroom'),
(12, 'Apprenez à programmer en javaScript', 50, 600, 'Cyrille Herby', 'Livre de Open Classroom');

-- --------------------------------------------------------

--
-- Structure de la table `Revue`
--

CREATE TABLE `Revue` (
  `Numero` int(11) NOT NULL,
  `Titre` varchar(30) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `Date_de_Sortie` date NOT NULL,
  `Commentaire` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Revue`
--

INSERT INTO `Revue` (`Numero`, `Titre`, `Prix`, `Date_de_Sortie`, `Commentaire`) VALUES
(1, 'La niège sur Paris', 3.65, '2018-01-01', 'Trois jours de niège à Paris !!!'),
(2, 'La negro renessance ', 6.36, '2018-02-02', 'La resistance africainne ');

-- --------------------------------------------------------

--
-- Structure de la table `Roman`
--

CREATE TABLE `Roman` (
  `Numero` int(11) NOT NULL,
  `Titre` varchar(40) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `NbPage` int(11) DEFAULT NULL,
  `Auteur` varchar(25) DEFAULT NULL,
  `Comentaire` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Roman`
--

INSERT INTO `Roman` (`Numero`, `Titre`, `Prix`, `NbPage`, `Auteur`, `Comentaire`) VALUES
(1, 'Les Ecails du ciel ', 15, 450, 'Thierno Mo Nenembo', 'Originaire de la Guinee'),
(2, 'Le monde s effondre', 12, 600, 'Chinua Achebe', 'Originaire du nigeria'),
(3, 'Contes', 30, 500, 'Andesen Christian', 'Originaire du Danemark'),
(5, 'Le père Goriot', 17, 450, 'Honoré de Balzac', 'Originaire de la France'),
(6, 'Décaméron', 15, 350, 'Boccace', 'Originaire de Italie'),
(7, 'L\' Etranger', 16, 450, 'Alber Camus', 'Originaire de la France'),
(8, 'Voyage au bout de la nuit', 17, 450, 'Louis Ferdinand', 'Originaire de la France'),
(9, 'L\' Enfant noir', 16, 250, 'Camara Laye', 'Originaire de la Guinee'),
(10, 'Le Ventre de l attlentique', 15, 450, 'Fatoiu Djome', 'Originaire du Sénégal');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `BandeDessinee`
--
ALTER TABLE `BandeDessinee`
  ADD PRIMARY KEY (`Numero`);

--
-- Index pour la table `Document`
--
ALTER TABLE `Document`
  ADD PRIMARY KEY (`Numero`);

--
-- Index pour la table `Livre`
--
ALTER TABLE `Livre`
  ADD PRIMARY KEY (`Numero`);

--
-- Index pour la table `Revue`
--
ALTER TABLE `Revue`
  ADD PRIMARY KEY (`Numero`);

--
-- Index pour la table `Roman`
--
ALTER TABLE `Roman`
  ADD PRIMARY KEY (`Numero`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `BandeDessinee`
--
ALTER TABLE `BandeDessinee`
  MODIFY `Numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `Document`
--
ALTER TABLE `Document`
  MODIFY `Numero` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `Livre`
--
ALTER TABLE `Livre`
  MODIFY `Numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `Revue`
--
ALTER TABLE `Revue`
  MODIFY `Numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `Roman`
--
ALTER TABLE `Roman`
  MODIFY `Numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;--
-- Base de données :  `Gestion Bibliotheque`
--
CREATE DATABASE IF NOT EXISTS `Gestion Bibliotheque` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Gestion Bibliotheque`;
--
-- Base de données :  `Gestion_Produit`
--
CREATE DATABASE IF NOT EXISTS `Gestion_Produit` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Gestion_Produit`;

-- --------------------------------------------------------

--
-- Structure de la table `Categorie`
--

CREATE TABLE `Categorie` (
  `ID_Categorie` smallint(5) UNSIGNED NOT NULL,
  `Nom_Categorie` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Categorie`
--

INSERT INTO `Categorie` (`ID_Categorie`, `Nom_Categorie`) VALUES
(1, 'Categorie A'),
(2, 'Categorie B'),
(3, 'Categorie C'),
(4, 'Categorie de type D'),
(5, 'Categorie de type E'),
(9, 'Categorie F'),
(10, 'Categorie F'),
(11, 'Categorie de type A2B12'),
(12, 'Categorie de type C14A125'),
(13, 'Categorie de type 125ALB888');

-- --------------------------------------------------------

--
-- Structure de la table `Produit`
--

CREATE TABLE `Produit` (
  `ID_Produit` smallint(5) UNSIGNED NOT NULL,
  `ID_Categorie` smallint(5) UNSIGNED NOT NULL,
  `Nom_Produit` varchar(50) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `Quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Produit`
--

INSERT INTO `Produit` (`ID_Produit`, `ID_Categorie`, `Nom_Produit`, `Prix`, `Quantite`) VALUES
(1, 2, 'Ail géant pourpe ', 5.95, 250),
(2, 2, 'Allium gladiator ', 6.5, 50),
(3, 2, 'Allium Ambassador : vrac ', 5.5, 260),
(4, 1, 'Allium Macleanii ', 5.5, 450),
(5, 1, 'Allium Nectaros siculum ', 5.5, 800),
(6, 1, 'Allium Christophii ', 5.5, 750),
(7, 1, 'Allium Purple Sensat ', 5.5, 450),
(8, 3, 'Ail d orenement Sphaerocephalon ', 3.5, 450),
(9, 4, 'Allium Roseum bulbes ', 2.95, 1050),
(10, 5, 'Allium Geant ', 5.5, 600),
(11, 5, 'Allium Globe master', 6.25, 950),
(12, 1, 'Aillum de Marseille', 8.12, 500),
(13, 1, 'Poir champ fleur de Angers ', 5.95, 800),
(14, 2, 'Poir champ de Guinnée ckry', 6.5, 950),
(15, 5, 'Allium Nectaros de Timbi ', 3.5, 800);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Categorie`
--
ALTER TABLE `Categorie`
  ADD PRIMARY KEY (`ID_Categorie`);

--
-- Index pour la table `Produit`
--
ALTER TABLE `Produit`
  ADD PRIMARY KEY (`ID_Produit`),
  ADD KEY `ID_Categorie` (`ID_Categorie`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Categorie`
--
ALTER TABLE `Categorie`
  MODIFY `ID_Categorie` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `Produit`
--
ALTER TABLE `Produit`
  MODIFY `ID_Produit` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Produit`
--
ALTER TABLE `Produit`
  ADD CONSTRAINT `Produit_ibfk_1` FOREIGN KEY (`ID_Categorie`) REFERENCES `Categorie` (`ID_Categorie`);
--
-- Base de données :  `School_Project`
--
CREATE DATABASE IF NOT EXISTS `School_Project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `School_Project`;

-- --------------------------------------------------------

--
-- Structure de la table `Administrateur`
--

CREATE TABLE `Administrateur` (
  `ID_Admin` int(10) UNSIGNED NOT NULL,
  `Nom_Admin` varchar(30) DEFAULT NULL,
  `Prenom_Admin` varchar(50) DEFAULT NULL,
  `Genre_Admin` varchar(2) DEFAULT NULL,
  `Date_Naissance` date DEFAULT NULL,
  `Lieu_Naissance` varchar(20) DEFAULT NULL,
  `Niveau_Admin` varchar(30) DEFAULT NULL,
  `Domaine_Admin` varchar(30) DEFAULT NULL,
  `Profil_Admin` varchar(40) DEFAULT NULL,
  `Domaine_Competence` varchar(30) DEFAULT NULL,
  `Langue_Maternelle` varchar(30) DEFAULT NULL,
  `Langue_Parlee` varchar(30) DEFAULT NULL,
  `Numero_Telephone` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Adresse_Admin` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Administrateur`
--

INSERT INTO `Administrateur` (`ID_Admin`, `Nom_Admin`, `Prenom_Admin`, `Genre_Admin`, `Date_Naissance`, `Lieu_Naissance`, `Niveau_Admin`, `Domaine_Admin`, `Profil_Admin`, `Domaine_Competence`, `Langue_Maternelle`, `Langue_Parlee`, `Numero_Telephone`, `Email`, `Adresse_Admin`) VALUES
(1, 'Root Diallo', 'Admin', 'H', NULL, 'Paname', 'Master 2', 'Developpement', 'Epert ', 'Java ', 'Franjçais ', 'Anglais ', '12454', 'diallo@diallo.fr', 'Paris'),
(2, 'Ikram', 'Admin', 'F', NULL, 'Maroc', 'L3', 'Miage', 'fvuuf', 'java', 'iodfihcn', 'ujdvuhbc', '1245', 'kfk@jd', 'paris'),
(4, 'test1123', 'test5245', 'H', NULL, 'zruisgujhçprgh', 'rhklrg', 'rgghbf', 'dqhet', 'srhttjh', 'qdthheq', 'qethtyh', '412457', 'ettkioetjeth', 'gliootlgk'),
(10, 'Barry', 'Bah', 'H', NULL, 'pita', 'l3', 'info', 'informatiq', 'java', 'fr', 'fr', '12456', '4578', 'paris'),
(11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `Authentification`
--

CREATE TABLE `Authentification` (
  `ID_Authentification` int(10) UNSIGNED NOT NULL,
  `Users` varchar(50) DEFAULT NULL,
  `Passwords` varchar(60) DEFAULT NULL,
  `Niveau` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Authentification`
--

INSERT INTO `Authentification` (`ID_Authentification`, `Users`, `Passwords`, `Niveau`) VALUES
(1, 'diallo', 'root', 2018);

-- --------------------------------------------------------

--
-- Structure de la table `Directeur`
--

CREATE TABLE `Directeur` (
  `ID_Directeur` int(10) UNSIGNED NOT NULL,
  `Nom_Directeur` varchar(30) DEFAULT NULL,
  `Prenom_Directeur` varchar(50) DEFAULT NULL,
  `Genre_Directeur` varchar(2) DEFAULT NULL,
  `Date_Naissance` date DEFAULT NULL,
  `Lieu_Naissance` varchar(20) DEFAULT NULL,
  `Niveau_Directeur` varchar(30) DEFAULT NULL,
  `Domaine_Directeur` varchar(30) DEFAULT NULL,
  `Profil_Directeur` varchar(40) DEFAULT NULL,
  `Domaine_Competence` varchar(30) DEFAULT NULL,
  `Langue_Maternelle` varchar(30) DEFAULT NULL,
  `Langue_Parlee` varchar(30) DEFAULT NULL,
  `Numero_Telephone` varchar(30) DEFAULT NULL,
  `Adresse_Email` varchar(30) DEFAULT NULL,
  `Adresse_Directeur` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Directeur`
--

INSERT INTO `Directeur` (`ID_Directeur`, `Nom_Directeur`, `Prenom_Directeur`, `Genre_Directeur`, `Date_Naissance`, `Lieu_Naissance`, `Niveau_Directeur`, `Domaine_Directeur`, `Profil_Directeur`, `Domaine_Competence`, `Langue_Maternelle`, `Langue_Parlee`, `Numero_Telephone`, `Adresse_Email`, `Adresse_Directeur`) VALUES
(1, 'Presi', 'Le President', 'M', NULL, 'France à Paris', 'Docteur ', 'Comptabilité', 'Enseignant', 'Java', 'Fraçais', 'Français', '0645454578', 'president@gmail.com', 'Pais '),
(2, 'Ikram', 'Ikram-Ik', 'F', NULL, 'Maroc', 'Licence 3', 'Miage', 'Etudiante', 'Geek', 'Arabe', 'Français', '012454', 'ikram@gmail.com', 'Evry'),
(3, 'fgrrfv', 'rqezg', 'H', NULL, 'grg', 'ggteaq', 'bt', 'bt', 'rg', 'jhh', 'rgg', '124', 'ryeqsh', 'upttth');

-- --------------------------------------------------------

--
-- Structure de la table `Enseignant`
--

CREATE TABLE `Enseignant` (
  `ID_Enseignant` int(10) UNSIGNED NOT NULL,
  `Nom_Enseignant` varchar(30) DEFAULT 'NOT NULL',
  `Prenom_Enseignant` varchar(50) DEFAULT NULL,
  `Genre_Enseignant` varchar(2) DEFAULT NULL,
  `Date_Naissance` date DEFAULT NULL,
  `Lieu_Naissance` varchar(20) DEFAULT NULL,
  `Niveau_Enseignant` varchar(30) DEFAULT NULL,
  `Domaine_Enseignant` varchar(30) DEFAULT NULL,
  `Profil_Enseignant` varchar(40) DEFAULT NULL,
  `Domaine_Competence` varchar(30) DEFAULT NULL,
  `Langue_Maternelle` varchar(30) DEFAULT NULL,
  `Langue_Parlee` varchar(30) DEFAULT NULL,
  `Numero_Telephone` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Adresse_Enseignant` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Enseignant`
--

INSERT INTO `Enseignant` (`ID_Enseignant`, `Nom_Enseignant`, `Prenom_Enseignant`, `Genre_Enseignant`, `Date_Naissance`, `Lieu_Naissance`, `Niveau_Enseignant`, `Domaine_Enseignant`, `Profil_Enseignant`, `Domaine_Competence`, `Langue_Maternelle`, `Langue_Parlee`, `Numero_Telephone`, `Email`, `Adresse_Enseignant`) VALUES
(2, 'DIALLO ', 'Thierno', 'H', '1993-01-05', 'Pita', 'Licene3', 'MIAGE', 'GEEK', 'Java', 'Peulh', 'Fraçais', '0783058507', 'thiernosd25', 'Vitry sur Seine'),
(3, 'Barry', 'Mamadou bobo', 'H', '2006-03-05', 'Coyah', 'Licene3', 'MIAGE', 'GEEK', 'Java', 'THôma', 'Fraçais', '0785963512', 'barry.mamad.com', 'Evry Concouronne'),
(4, 'Barry', 'Mamadou bobo', 'H', NULL, 'Coyah', 'Licene3', 'MIAGE', 'GEEK', 'Java', 'THôma', 'Fraçais', '0785963512', 'barry.mamad.com', 'Evry Concouronne'),
(5, 'grhg', 'erthy', NULL, NULL, 'thz\'', 'tghtgh', 'rth', 'rthzh', 'tz', 'qzt', 'hgth', '02145', 'tghgt', 'stght'),
(6, 'Ikram', 'Ikra', 'F', NULL, 'Maroc', 'L3', 'MIAGE', 'ETUD', 'JDHD', 'AEFZ', 'AZ', '255487', '1245', 'PARIS');

-- --------------------------------------------------------

--
-- Structure de la table `Enseignant_Matiere`
--

CREATE TABLE `Enseignant_Matiere` (
  `ID_Enseignant` int(10) UNSIGNED NOT NULL,
  `ID_Matiere` int(10) UNSIGNED NOT NULL,
  `Nombre_Heure` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Enseignant_Matiere`
--

INSERT INTO `Enseignant_Matiere` (`ID_Enseignant`, `ID_Matiere`, `Nombre_Heure`) VALUES
(2, 1, '30 heure');

-- --------------------------------------------------------

--
-- Structure de la table `Etudiant`
--

CREATE TABLE `Etudiant` (
  `ID_Etudiant` int(10) UNSIGNED NOT NULL,
  `Nom_Etudiant` varchar(30) DEFAULT NULL,
  `Prenom_Etudiant` varchar(50) DEFAULT NULL,
  `Genre` varchar(20) DEFAULT NULL,
  `Date_Naissance` date DEFAULT NULL,
  `Lieu_Naissance` varchar(20) DEFAULT NULL,
  `Niveau` varchar(30) DEFAULT NULL,
  `Domaine` varchar(30) DEFAULT NULL,
  `Profil` varchar(40) DEFAULT NULL,
  `Competence` varchar(30) DEFAULT NULL,
  `Lang_Maternelle` varchar(30) DEFAULT NULL,
  `Lang_Parlee` varchar(30) DEFAULT NULL,
  `Telephone` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Adresse_Etudiant` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Etudiant`
--

INSERT INTO `Etudiant` (`ID_Etudiant`, `Nom_Etudiant`, `Prenom_Etudiant`, `Genre`, `Date_Naissance`, `Lieu_Naissance`, `Niveau`, `Domaine`, `Profil`, `Competence`, `Lang_Maternelle`, `Lang_Parlee`, `Telephone`, `Email`, `Adresse_Etudiant`) VALUES
(1, 'DIALLO', 'THIRNO', 'H', NULL, 'PITA', 'Licence3', 'MIAGE/Geek', 'Etudiant', 'Java', 'fr', 'us', '021547', 'tsd@tsd.fr', 'Paris'),
(2, 'DIALLO', 'Souleymane', 'H', NULL, 'PITA', 'Licence3', 'MIAGE/Geek', 'Etudiant', 'Java', 'fr', 'us', '021547', 'tsd@tsd.fr', 'Paris'),
(3, 'Barry', 'Mamadou bobo', 'H', '2006-03-05', 'Coyah', 'Licene3', 'MIAGE', 'GEEK', 'Java', 'THôma', 'Fraçais', '0785963512', 'barry.mamad.com', 'Evry Concouronne');

-- --------------------------------------------------------

--
-- Structure de la table `Groupe`
--

CREATE TABLE `Groupe` (
  `ID_Groupe` int(10) UNSIGNED NOT NULL,
  `Nom_Groupe` varchar(30) DEFAULT NULL,
  `Date_Examen_Groupe` date DEFAULT NULL,
  `ID_Horaire` int(10) UNSIGNED NOT NULL,
  `ID_Session` int(10) UNSIGNED NOT NULL,
  `ID_Salle` int(10) UNSIGNED NOT NULL,
  `ID_Module` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Horaire`
--

CREATE TABLE `Horaire` (
  `ID_Horaire` int(10) UNSIGNED NOT NULL,
  `Libelle_Horaire` varchar(50) DEFAULT NULL,
  `Nombre_Heure` varchar(30) DEFAULT NULL,
  `ID_Session` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Inscription`
--

CREATE TABLE `Inscription` (
  `ID_Inscription` int(10) UNSIGNED NOT NULL,
  `ID_Etudiant` int(10) UNSIGNED NOT NULL,
  `ID_Groupe` int(10) UNSIGNED NOT NULL,
  `ID_Session` int(10) UNSIGNED NOT NULL,
  `ID_Paiement` int(10) UNSIGNED NOT NULL,
  `Date_Inscription` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Matiere`
--

CREATE TABLE `Matiere` (
  `ID_Matiere` int(10) UNSIGNED NOT NULL,
  `Nom_Matiere` int(11) DEFAULT NULL,
  `Libele_Matiere` varchar(30) DEFAULT NULL,
  `Lang_Libele_Matiere` varchar(80) DEFAULT NULL,
  `Niveau_Matiere` varchar(50) DEFAULT NULL,
  `ID_Module` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Matiere`
--

INSERT INTO `Matiere` (`ID_Matiere`, `Nom_Matiere`, `Libele_Matiere`, `Lang_Libele_Matiere`, `Niveau_Matiere`, `ID_Module`) VALUES
(1, 1, 'jjr', 'tsrgtgg', 'bgfffff', 1),
(2, 1245, 'dihbcdhigd', 'dbijdhbudi', 'ijbdzj', 1);

-- --------------------------------------------------------

--
-- Structure de la table `Module`
--

CREATE TABLE `Module` (
  `ID_Module` int(10) UNSIGNED NOT NULL,
  `Libele_Module` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Module`
--

INSERT INTO `Module` (`ID_Module`, `Libele_Module`) VALUES
(1, 'gchk');

-- --------------------------------------------------------

--
-- Structure de la table `Note`
--

CREATE TABLE `Note` (
  `ID_Etudiant` int(10) UNSIGNED NOT NULL,
  `ID_Matiere` int(10) UNSIGNED NOT NULL,
  `Note` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Note`
--

INSERT INTO `Note` (`ID_Etudiant`, `ID_Matiere`, `Note`) VALUES
(1, 1, 15),
(2, 1, 11),
(3, 1, 17),
(3, 2, 19);

-- --------------------------------------------------------

--
-- Structure de la table `Paiement`
--

CREATE TABLE `Paiement` (
  `ID_Paiement` int(10) UNSIGNED NOT NULL,
  `Tarifs` int(30) DEFAULT NULL,
  `Montant_HT` double DEFAULT NULL,
  `Montant_TTC` double DEFAULT NULL,
  `Restant_du` double DEFAULT NULL,
  `Date_Echeance1` date DEFAULT NULL,
  `Date_Echeance2` date DEFAULT NULL,
  `Date_Echeance3` date DEFAULT NULL,
  `Recus_Echeance1` varchar(50) DEFAULT NULL,
  `Recus_Echeance2` varchar(50) DEFAULT NULL,
  `Recus_Echeance3` varchar(50) DEFAULT NULL,
  `Commentaire` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Salle`
--

CREATE TABLE `Salle` (
  `ID_Salle` int(10) UNSIGNED NOT NULL,
  `Nom_Salle` varchar(30) DEFAULT NULL,
  `Capacite_Salle` int(11) DEFAULT NULL,
  `Disonibilite` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Secretaire`
--

CREATE TABLE `Secretaire` (
  `ID_Secretaire` int(10) UNSIGNED NOT NULL,
  `Nom_Secretaire` varchar(30) DEFAULT NULL,
  `Prenom_Secretaire` varchar(50) DEFAULT NULL,
  `Genre_Secretaire` varchar(2) DEFAULT NULL,
  `Date_Naissance` date DEFAULT NULL,
  `Lieu_Naissance` varchar(20) DEFAULT NULL,
  `Niveau_Secretaire` varchar(30) DEFAULT NULL,
  `Domaine_Secretaire` varchar(30) DEFAULT NULL,
  `Profil_Secretaire` varchar(40) DEFAULT NULL,
  `Domaine_Competence` varchar(30) DEFAULT NULL,
  `Langue_Maternelle` varchar(30) DEFAULT NULL,
  `Langue_Parlee` varchar(30) DEFAULT NULL,
  `Numero_Telephone` varchar(30) DEFAULT NULL,
  `Adresse_Email` varchar(30) DEFAULT NULL,
  `Adresse_Secretaire` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Sessions`
--

CREATE TABLE `Sessions` (
  `ID_Session` int(10) UNSIGNED NOT NULL,
  `ID_Annee` int(11) DEFAULT NULL,
  `Nom_Session` varchar(30) DEFAULT NULL,
  `Date_Debut_Session` date DEFAULT NULL,
  `Date_Fin_Session` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Sessions`
--

INSERT INTO `Sessions` (`ID_Session`, `ID_Annee`, `Nom_Session`, `Date_Debut_Session`, `Date_Fin_Session`) VALUES
(1, 2018, 'session1', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `SuiviPedagogique`
--

CREATE TABLE `SuiviPedagogique` (
  `ID_Pedagogique` int(10) UNSIGNED NOT NULL,
  `ID_Etudiant` int(10) UNSIGNED NOT NULL,
  `Liste_Absence` varchar(250) DEFAULT NULL,
  `Liste_Session` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Tarif`
--

CREATE TABLE `Tarif` (
  `ID_Tarif` double UNSIGNED NOT NULL,
  `Montant1_Groupe` double DEFAULT NULL,
  `Montant2_Groupe` double DEFAULT NULL,
  `Montant3_Groupe` double DEFAULT NULL,
  `AnneRef` varchar(50) DEFAULT NULL,
  `ID_Session` int(10) UNSIGNED NOT NULL,
  `Remise_Immediat` double DEFAULT NULL,
  `Remise3_Groupe` double DEFAULT NULL,
  `Remise_Annuelle` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Administrateur`
--
ALTER TABLE `Administrateur`
  ADD PRIMARY KEY (`ID_Admin`);

--
-- Index pour la table `Authentification`
--
ALTER TABLE `Authentification`
  ADD PRIMARY KEY (`ID_Authentification`);

--
-- Index pour la table `Directeur`
--
ALTER TABLE `Directeur`
  ADD PRIMARY KEY (`ID_Directeur`);

--
-- Index pour la table `Enseignant`
--
ALTER TABLE `Enseignant`
  ADD PRIMARY KEY (`ID_Enseignant`);

--
-- Index pour la table `Enseignant_Matiere`
--
ALTER TABLE `Enseignant_Matiere`
  ADD KEY `ID_Enseignant` (`ID_Enseignant`),
  ADD KEY `ID_Matiere` (`ID_Matiere`);

--
-- Index pour la table `Etudiant`
--
ALTER TABLE `Etudiant`
  ADD PRIMARY KEY (`ID_Etudiant`);

--
-- Index pour la table `Groupe`
--
ALTER TABLE `Groupe`
  ADD PRIMARY KEY (`ID_Groupe`),
  ADD KEY `ID_Session` (`ID_Session`),
  ADD KEY `ID_Salle` (`ID_Salle`),
  ADD KEY `ID_Module` (`ID_Module`),
  ADD KEY `ID_Horaire` (`ID_Horaire`);

--
-- Index pour la table `Horaire`
--
ALTER TABLE `Horaire`
  ADD PRIMARY KEY (`ID_Horaire`),
  ADD KEY `ID_Session` (`ID_Session`);

--
-- Index pour la table `Inscription`
--
ALTER TABLE `Inscription`
  ADD PRIMARY KEY (`ID_Inscription`),
  ADD KEY `ID_Etudiant` (`ID_Etudiant`),
  ADD KEY `ID_Groupe` (`ID_Groupe`),
  ADD KEY `ID_Session` (`ID_Session`),
  ADD KEY `ID_Paiement` (`ID_Paiement`);

--
-- Index pour la table `Matiere`
--
ALTER TABLE `Matiere`
  ADD PRIMARY KEY (`ID_Matiere`),
  ADD KEY `ID_Module` (`ID_Module`);

--
-- Index pour la table `Module`
--
ALTER TABLE `Module`
  ADD PRIMARY KEY (`ID_Module`);

--
-- Index pour la table `Note`
--
ALTER TABLE `Note`
  ADD PRIMARY KEY (`ID_Etudiant`,`ID_Matiere`),
  ADD KEY `ID_Matiere` (`ID_Matiere`);

--
-- Index pour la table `Paiement`
--
ALTER TABLE `Paiement`
  ADD PRIMARY KEY (`ID_Paiement`);

--
-- Index pour la table `Salle`
--
ALTER TABLE `Salle`
  ADD PRIMARY KEY (`ID_Salle`);

--
-- Index pour la table `Secretaire`
--
ALTER TABLE `Secretaire`
  ADD PRIMARY KEY (`ID_Secretaire`);

--
-- Index pour la table `Sessions`
--
ALTER TABLE `Sessions`
  ADD PRIMARY KEY (`ID_Session`);

--
-- Index pour la table `SuiviPedagogique`
--
ALTER TABLE `SuiviPedagogique`
  ADD PRIMARY KEY (`ID_Pedagogique`),
  ADD KEY `ID_Etudiant` (`ID_Etudiant`);

--
-- Index pour la table `Tarif`
--
ALTER TABLE `Tarif`
  ADD PRIMARY KEY (`ID_Tarif`),
  ADD KEY `ID_Session` (`ID_Session`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Administrateur`
--
ALTER TABLE `Administrateur`
  MODIFY `ID_Admin` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `Authentification`
--
ALTER TABLE `Authentification`
  MODIFY `ID_Authentification` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `Directeur`
--
ALTER TABLE `Directeur`
  MODIFY `ID_Directeur` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `Enseignant`
--
ALTER TABLE `Enseignant`
  MODIFY `ID_Enseignant` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `Etudiant`
--
ALTER TABLE `Etudiant`
  MODIFY `ID_Etudiant` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `Groupe`
--
ALTER TABLE `Groupe`
  MODIFY `ID_Groupe` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Inscription`
--
ALTER TABLE `Inscription`
  MODIFY `ID_Inscription` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Matiere`
--
ALTER TABLE `Matiere`
  MODIFY `ID_Matiere` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `Module`
--
ALTER TABLE `Module`
  MODIFY `ID_Module` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `Paiement`
--
ALTER TABLE `Paiement`
  MODIFY `ID_Paiement` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Salle`
--
ALTER TABLE `Salle`
  MODIFY `ID_Salle` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Secretaire`
--
ALTER TABLE `Secretaire`
  MODIFY `ID_Secretaire` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Sessions`
--
ALTER TABLE `Sessions`
  MODIFY `ID_Session` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `SuiviPedagogique`
--
ALTER TABLE `SuiviPedagogique`
  MODIFY `ID_Pedagogique` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Tarif`
--
ALTER TABLE `Tarif`
  MODIFY `ID_Tarif` double UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Enseignant_Matiere`
--
ALTER TABLE `Enseignant_Matiere`
  ADD CONSTRAINT `Enseignant_Matiere_ibfk_1` FOREIGN KEY (`ID_Enseignant`) REFERENCES `Enseignant` (`ID_Enseignant`),
  ADD CONSTRAINT `Enseignant_Matiere_ibfk_2` FOREIGN KEY (`ID_Matiere`) REFERENCES `Matiere` (`ID_Matiere`);

--
-- Contraintes pour la table `Groupe`
--
ALTER TABLE `Groupe`
  ADD CONSTRAINT `Groupe_ibfk_1` FOREIGN KEY (`ID_Session`) REFERENCES `Sessions` (`ID_Session`),
  ADD CONSTRAINT `Groupe_ibfk_2` FOREIGN KEY (`ID_Salle`) REFERENCES `Salle` (`ID_Salle`),
  ADD CONSTRAINT `Groupe_ibfk_3` FOREIGN KEY (`ID_Module`) REFERENCES `Module` (`ID_Module`),
  ADD CONSTRAINT `Groupe_ibfk_4` FOREIGN KEY (`ID_Horaire`) REFERENCES `Horaire` (`ID_Horaire`);

--
-- Contraintes pour la table `Horaire`
--
ALTER TABLE `Horaire`
  ADD CONSTRAINT `Horaire_ibfk_1` FOREIGN KEY (`ID_Session`) REFERENCES `Sessions` (`ID_Session`);

--
-- Contraintes pour la table `Inscription`
--
ALTER TABLE `Inscription`
  ADD CONSTRAINT `Inscription_ibfk_1` FOREIGN KEY (`ID_Etudiant`) REFERENCES `Etudiant` (`ID_Etudiant`),
  ADD CONSTRAINT `Inscription_ibfk_2` FOREIGN KEY (`ID_Groupe`) REFERENCES `Groupe` (`ID_Groupe`),
  ADD CONSTRAINT `Inscription_ibfk_3` FOREIGN KEY (`ID_Session`) REFERENCES `Sessions` (`ID_Session`),
  ADD CONSTRAINT `Inscription_ibfk_4` FOREIGN KEY (`ID_Paiement`) REFERENCES `Paiement` (`ID_Paiement`);

--
-- Contraintes pour la table `Matiere`
--
ALTER TABLE `Matiere`
  ADD CONSTRAINT `Matiere_ibfk_1` FOREIGN KEY (`ID_Module`) REFERENCES `Module` (`ID_Module`);

--
-- Contraintes pour la table `Note`
--
ALTER TABLE `Note`
  ADD CONSTRAINT `Note_ibfk_1` FOREIGN KEY (`ID_Etudiant`) REFERENCES `Etudiant` (`ID_Etudiant`),
  ADD CONSTRAINT `Note_ibfk_2` FOREIGN KEY (`ID_Matiere`) REFERENCES `Matiere` (`ID_Matiere`);

--
-- Contraintes pour la table `SuiviPedagogique`
--
ALTER TABLE `SuiviPedagogique`
  ADD CONSTRAINT `SuiviPedagogique_ibfk_1` FOREIGN KEY (`ID_Etudiant`) REFERENCES `Etudiant` (`ID_Etudiant`);

--
-- Contraintes pour la table `Tarif`
--
ALTER TABLE `Tarif`
  ADD CONSTRAINT `Tarif_ibfk_1` FOREIGN KEY (`ID_Session`) REFERENCES `Sessions` (`ID_Session`);
--
-- Base de données :  `TP5_Athentification`
--
CREATE DATABASE IF NOT EXISTS `TP5_Athentification` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `TP5_Athentification`;

-- --------------------------------------------------------

--
-- Structure de la table `Login`
--

CREATE TABLE `Login` (
  `ID_Users` int(10) UNSIGNED NOT NULL,
  `User_Name` varchar(50) DEFAULT NULL,
  `Passwords` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Login`
--

INSERT INTO `Login` (`ID_Users`, `User_Name`, `Passwords`) VALUES
(1, 'Admin', 'root'),
(2, 'user', 'user');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Login`
--
ALTER TABLE `Login`
  ADD PRIMARY KEY (`ID_Users`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Login`
--
ALTER TABLE `Login`
  MODIFY `ID_Users` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;--
-- Base de données :  `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `phpmyadmin`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
